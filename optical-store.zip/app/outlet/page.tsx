"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Filter, ChevronDown, ChevronUp, Percent } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import ProductCard from "@/components/product-card"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

// Mock data for outlet products
const outletProducts = [
  {
    id: "outlet-1",
    name: "Óculos de Sol Ray-Ban Justin",
    brand: "Ray-Ban",
    price: 399.9,
    originalPrice: 699.9,
    discount: 43,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    colors: ["#000000", "#714B23"],
    isNew: false,
  },
  {
    id: "outlet-2",
    name: "Óculos de Sol Oakley Holbrook",
    brand: "Oakley",
    price: 449.9,
    originalPrice: 799.9,
    discount: 44,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    colors: ["#000000", "#1A2B3C"],
    isNew: false,
  },
  {
    id: "outlet-3",
    name: "Óculos de Grau Tommy Hilfiger TH1234",
    brand: "Tommy Hilfiger",
    price: 349.9,
    originalPrice: 599.9,
    discount: 42,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#0F4D92"],
    isNew: false,
  },
  {
    id: "outlet-4",
    name: "Óculos de Grau Vogue VO5123",
    brand: "Vogue",
    price: 299.9,
    originalPrice: 499.9,
    discount: 40,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#8B4513"],
    isNew: false,
  },
  {
    id: "outlet-5",
    name: "Lentes de Contato Coloridas FreshLook",
    brand: "FreshLook",
    price: 99.9,
    originalPrice: 149.9,
    discount: 33,
    image: "/placeholder.svg?height=300&width=300",
    category: "lentes-de-contato",
    colors: ["#A5764E", "#0F4D92"],
    isNew: false,
  },
  {
    id: "outlet-6",
    name: "Óculos de Sol Prada PR 17WS",
    brand: "Prada",
    price: 899.9,
    originalPrice: 1599.9,
    discount: 44,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    colors: ["#000000", "#1A1A1A"],
    isNew: false,
  },
  {
    id: "outlet-7",
    name: "Óculos de Grau Armani Exchange AX3048",
    brand: "Armani Exchange",
    price: 499.9,
    originalPrice: 799.9,
    discount: 38,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#1A1A1A", "#4A4A4A"],
    isNew: false,
  },
  {
    id: "outlet-8",
    name: "Óculos de Sol Versace VE4361",
    brand: "Versace",
    price: 799.9,
    originalPrice: 1399.9,
    discount: 43,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#FFD700"],
    isNew: false,
  },
  {
    id: "outlet-9",
    name: "Lentes de Contato Coloridas Solotica",
    brand: "Solotica",
    price: 99.9,
    originalPrice: 149.9,
    discount: 33,
    image: "/placeholder.svg?height=300&width=300",
    category: "lentes-de-contato",
    colors: ["#A5764E", "#0F4D92", "#2D5335"],
    isNew: false,
  },
  {
    id: "outlet-10",
    name: "Óculos de Grau Gucci GG0297OK",
    brand: "Gucci",
    price: 999.9,
    originalPrice: 1599.9,
    discount: 38,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#714B23"],
    isNew: false,
  },
  {
    id: "outlet-11",
    name: "Óculos de Sol Carrera 1007/S",
    brand: "Carrera",
    price: 399.9,
    originalPrice: 699.9,
    discount: 43,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    colors: ["#000000", "#0F4D92", "#8B0000"],
    isNew: false,
  },
  {
    id: "outlet-12",
    name: "Óculos de Grau Michael Kors MK4067",
    brand: "Michael Kors",
    price: 499.9,
    originalPrice: 899.9,
    discount: 44,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#C0C0C0", "#8B4513"],
    isNew: false,
  },
]

const brands = [
  "Todas as marcas",
  "Ray-Ban",
  "Oakley",
  "Tommy Hilfiger",
  "Vogue",
  "FreshLook",
  "Prada",
  "Armani Exchange",
  "Versace",
  "Solotica",
  "Gucci",
  "Carrera",
  "Michael Kors",
]

const categories = ["Todas as categorias", "Óculos de Sol", "Óculos de Grau", "Lentes de Contato"]

const discountRanges = ["Todos os descontos", "Até 30%", "30% a 40%", "40% a 50%", "Acima de 50%"]

export default function OutletPage() {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000])
  const [selectedBrand, setSelectedBrand] = useState("Todas as marcas")
  const [selectedCategory, setSelectedCategory] = useState("Todas as categorias")
  const [selectedDiscountRange, setSelectedDiscountRange] = useState("Todos os descontos")
  const [sortBy, setSortBy] = useState("discount-desc")

  // Filter products based on selected filters
  const filteredProducts = outletProducts.filter((product) => {
    // Filter by price range
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false
    }

    // Filter by brand
    if (selectedBrand !== "Todas as marcas" && product.brand !== selectedBrand) {
      return false
    }

    // Filter by category
    if (selectedCategory !== "Todas as categorias") {
      if (selectedCategory === "Óculos de Sol" && product.category !== "oculos-de-sol") {
        return false
      }
      if (selectedCategory === "Óculos de Grau" && product.category !== "oculos-de-grau") {
        return false
      }
      if (selectedCategory === "Lentes de Contato" && product.category !== "lentes-de-contato") {
        return false
      }
    }

    // Filter by discount range
    if (selectedDiscountRange !== "Todos os descontos") {
      const discount = product.discount || 0
      if (selectedDiscountRange === "Até 30%" && discount >= 30) {
        return false
      }
      if (selectedDiscountRange === "30% a 40%" && (discount < 30 || discount >= 40)) {
        return false
      }
      if (selectedDiscountRange === "40% a 50%" && (discount < 40 || discount >= 50)) {
        return false
      }
      if (selectedDiscountRange === "Acima de 50%" && discount < 50) {
        return false
      }
    }

    return true
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return a.price - b.price
      case "price-desc":
        return b.price - a.price
      case "name-asc":
        return a.name.localeCompare(b.name)
      case "name-desc":
        return b.name.localeCompare(a.name)
      case "discount-desc":
        return (b.discount || 0) - (a.discount || 0)
      default:
        return 0
    }
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col space-y-4">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-purple-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-900 font-medium">Outlet</span>
        </nav>

        {/* Hero Banner */}
        <div className="relative w-full h-64 md:h-80 rounded-xl overflow-hidden mb-8">
          <Image
            src="/placeholder.svg?height=400&width=1200"
            alt="Outlet Banner"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-red-500/80 to-orange-500/80"></div>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-white p-6 text-center">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">OUTLET</h1>
            <p className="text-lg md:text-xl mb-6 max-w-xl">
              Aproveite descontos de até 50% em produtos selecionados. Ofertas por tempo limitado!
            </p>
            <Badge className="bg-white text-red-600 text-lg py-1 px-3">
              <Percent className="h-4 w-4 mr-1" />
              SUPER OFERTAS
            </Badge>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="hidden md:block w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Filtros</h2>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Preço</h3>
                <Slider
                  defaultValue={[0, 2000]}
                  max={2000}
                  step={50}
                  value={priceRange}
                  onValueChange={(value) => setPriceRange(value as [number, number])}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>R$ {priceRange[0]}</span>
                  <span>R$ {priceRange[1]}</span>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Categories */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Categorias</h3>
                <RadioGroup value={selectedCategory} onValueChange={setSelectedCategory}>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category} className="flex items-center">
                        <RadioGroupItem value={category} id={`category-${category}`} />
                        <Label htmlFor={`category-${category}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {category}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Brands */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Marcas</h3>
                <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                  <div className="space-y-2">
                    {brands.map((brand) => (
                      <div key={brand} className="flex items-center">
                        <RadioGroupItem value={brand} id={`brand-${brand}`} />
                        <Label htmlFor={`brand-${brand}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {brand}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Discount Range */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Faixa de Desconto</h3>
                <RadioGroup value={selectedDiscountRange} onValueChange={setSelectedDiscountRange}>
                  <div className="space-y-2">
                    {discountRanges.map((range) => (
                      <div key={range} className="flex items-center">
                        <RadioGroupItem value={range} id={`discount-${range}`} />
                        <Label htmlFor={`discount-${range}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {range}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setPriceRange([0, 2000])
                  setSelectedBrand("Todas as marcas")
                  setSelectedCategory("Todas as categorias")
                  setSelectedDiscountRange("Todos os descontos")
                }}
              >
                Limpar Filtros
              </Button>
            </div>
          </div>

          {/* Mobile Filters */}
          <div className="md:hidden mb-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center justify-center">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px] overflow-auto">
                <div className="py-4">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">Filtros</h2>

                  {/* Price Range */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Preço</h3>
                    <Slider
                      defaultValue={[0, 2000]}
                      max={2000}
                      step={50}
                      value={priceRange}
                      onValueChange={(value) => setPriceRange(value as [number, number])}
                      className="mb-2"
                    />
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>R$ {priceRange[0]}</span>
                      <span>R$ {priceRange[1]}</span>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Categories */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Categorias</h3>
                    <RadioGroup value={selectedCategory} onValueChange={setSelectedCategory}>
                      <div className="space-y-2">
                        {categories.map((category) => (
                          <div key={category} className="flex items-center">
                            <RadioGroupItem value={category} id={`mobile-category-${category}`} />
                            <Label
                              htmlFor={`mobile-category-${category}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {category}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator className="my-4" />

                  {/* Brands */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Marcas</h3>
                    <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                      <div className="space-y-2">
                        {brands.slice(0, 6).map((brand) => (
                          <div key={brand} className="flex items-center">
                            <RadioGroupItem value={brand} id={`mobile-brand-${brand}`} />
                            <Label
                              htmlFor={`mobile-brand-${brand}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {brand}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator className="my-4" />

                  {/* Discount Range */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Faixa de Desconto</h3>
                    <RadioGroup value={selectedDiscountRange} onValueChange={setSelectedDiscountRange}>
                      <div className="space-y-2">
                        {discountRanges.map((range) => (
                          <div key={range} className="flex items-center">
                            <RadioGroupItem value={range} id={`mobile-discount-${range}`} />
                            <Label
                              htmlFor={`mobile-discount-${range}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {range}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setPriceRange([0, 2000])
                      setSelectedBrand("Todas as marcas")
                      setSelectedCategory("Todas as categorias")
                      setSelectedDiscountRange("Todos os descontos")
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Products */}
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0">Outlet - Grandes Descontos</h1>

                {/* Sort */}
                <div className="w-full sm:w-auto">
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full sm:w-[200px]">
                      <SelectValue placeholder="Ordenar por" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="discount-desc">Maior Desconto</SelectItem>
                      <SelectItem value="price-asc">Menor Preço</SelectItem>
                      <SelectItem value="price-desc">Maior Preço</SelectItem>
                      <SelectItem value="name-asc">Nome (A-Z)</SelectItem>
                      <SelectItem value="name-desc">Nome (Z-A)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Products Grid */}
              {sortedProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sortedProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">Nenhum produto encontrado com os filtros selecionados.</p>
                  <Button
                    variant="outline"
                    className="mt-4"
                    onClick={() => {
                      setPriceRange([0, 2000])
                      setSelectedBrand("Todas as marcas")
                      setSelectedCategory("Todas as categorias")
                      setSelectedDiscountRange("Todos os descontos")
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              )}

              {/* Pagination */}
              {sortedProducts.length > 0 && (
                <div className="flex justify-center mt-8">
                  <nav className="flex items-center space-x-2">
                    <Button variant="outline" size="icon" disabled>
                      <ChevronUp className="h-4 w-4 rotate-90" />
                    </Button>
                    <Button variant="outline" size="sm" className="bg-purple-600 text-white hover:bg-purple-700">
                      1
                    </Button>
                    <Button variant="outline" size="sm">
                      2
                    </Button>
                    <Button variant="outline" size="sm">
                      3
                    </Button>
                    <Button variant="outline" size="icon">
                      <ChevronDown className="h-4 w-4 rotate-90" />
                    </Button>
                  </nav>
                </div>
              )}
            </div>

            {/* Outlet Information */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Sobre o Outlet</h2>
              <div className="text-gray-700 space-y-4">
                <p>
                  Nossa seção Outlet oferece produtos com grandes descontos. São itens de coleções anteriores, últimas
                  unidades ou com pequenas imperfeições estéticas que não comprometem a qualidade ou funcionalidade.
                </p>
                <p>
                  Todos os produtos do Outlet passam por rigorosa inspeção de qualidade e mantêm a mesma garantia dos
                  produtos de linha. É uma excelente oportunidade para adquirir produtos de marcas renomadas com preços
                  especiais.
                </p>
                <div className="bg-red-50 p-4 rounded-md mt-4">
                  <p className="text-red-800 font-medium">
                    Atenção: Os produtos do Outlet possuem estoque limitado e, uma vez esgotados, podem não ser
                    repostos. Aproveite enquanto durar!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

