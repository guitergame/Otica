"use client"
import Image from "next/image"
import Link from "next/link"
import { Trash2, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useWishlist } from "@/components/wishlist-provider"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth-provider"
import { useRouter } from "next/navigation"

export default function WishlistPage() {
  const { wishlistItems, removeFromWishlist, clearWishlist } = useWishlist()
  const { addToCart } = useCart()
  const { toast } = useToast()
  const { isAuthenticated } = useAuth()
  const router = useRouter()

  const handleRemoveFromWishlist = (productId: string) => {
    removeFromWishlist(productId)
    toast({
      title: "Produto removido",
      description: "O produto foi removido dos seus favoritos.",
    })
  }

  const handleAddToCart = (product: any) => {
    addToCart(product)
    toast({
      title: "Produto adicionado ao carrinho",
      description: `${product.name} foi adicionado ao seu carrinho.`,
    })
  }

  const handleClearWishlist = () => {
    clearWishlist()
    toast({
      title: "Lista de desejos limpa",
      description: "Todos os produtos foram removidos dos seus favoritos.",
    })
  }

  if (!isAuthenticated) {
    router.push("/login?redirect=/wishlist")
    return null
  }

  if (wishlistItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Meus Favoritos</h1>
        <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-700 mb-6">Sua lista de favoritos está vazia.</p>
          <Link href="/produtos">
            <Button className="bg-purple-600 hover:bg-purple-700">Explorar Produtos</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Meus Favoritos</h1>
        <Button variant="outline" onClick={handleClearWishlist} className="mt-4 md:mt-0">
          Limpar Lista
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="py-3 px-4 text-left font-medium text-gray-700">Produto</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Preço</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Disponibilidade</th>
                <th className="py-3 px-4 text-right font-medium text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {wishlistItems.map((item) => (
                <tr key={item.id} className="border-b border-gray-200 hover:bg-gray-50">
                  <td className="py-4 px-4">
                    <div className="flex items-center">
                      <div className="relative w-16 h-16 flex-shrink-0">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          fill
                          className="object-cover rounded-md"
                        />
                      </div>
                      <div className="ml-4">
                        <Link href={`/produto/${item.id}`}>
                          <h3 className="font-medium text-gray-900 hover:text-purple-700 transition-colors">
                            {item.name}
                          </h3>
                        </Link>
                        <p className="text-sm text-gray-500">{item.brand}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    {item.originalPrice && item.originalPrice > item.price ? (
                      <div className="flex flex-col">
                        <span className="font-medium text-gray-900">R$ {item.price.toFixed(2)}</span>
                        <span className="text-sm text-gray-500 line-through">R$ {item.originalPrice.toFixed(2)}</span>
                      </div>
                    ) : (
                      <span className="font-medium text-gray-900">R$ {item.price.toFixed(2)}</span>
                    )}
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-green-600">Em estoque</span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleAddToCart(item)}>
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Adicionar ao Carrinho
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleRemoveFromWishlist(item.id)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                        <span className="sr-only">Remover</span>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

