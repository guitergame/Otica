"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"
import { ShoppingCart, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-provider"
import { useWishlist } from "@/components/wishlist-provider"
import { useToast } from "@/components/ui/use-toast"
import ProductGrid from "@/components/product-grid"
import { formatCurrency } from "@/lib/utils"

// Mock product data - in a real app, this would come from an API
const mockProduct = {
  id: "1",
  name: "Óculos de Sol Ray-Ban Aviator Classic",
  brand: "Ray-Ban",
  price: 599.9,
  originalPrice: 799.9,
  discount: 25,
  description:
    "Os óculos de sol Ray-Ban Aviator Classic são verdadeiramente icônicos. Criados originalmente para os aviadores dos EUA, os Aviator Classic são um modelo atemporal que combina um estilo retrô com um design contemporâneo. Apresentando lentes em formato de gota, uma armação fina de metal e um conforto incomparável.",
  features: [
    "Armação em metal dourado",
    "Lentes em cristal verde G-15",
    "100% de proteção contra raios UVA e UVB",
    "Inclui estojo e pano de limpeza",
    "Tamanho: 58mm",
  ],
  colors: [
    { name: "Dourado/Verde", code: "#714B23", image: "/images/sunglasses1.png" },
    { name: "Preto/Verde", code: "#000000", image: "/images/sunglasses2.png" },
    { name: "Prata/Azul", code: "#C0C0C0", image: "/images/glasses1.png" },
    { name: "Prata/Azul", code: "#C0C0C0", image: "/images/glasses2.png" },
  ],
  sizes: ["52mm", "55mm", "58mm", "62mm"],
  rating: 4.8,
  reviewCount: 423,
  stock: 15,
  sku: "RB3025-L0205-58",
  category: "oculos-de-sol",
  isNew: false,
  isPrescription: false,
  image: "/images/sunglasses1.png",
}

export default function ProductPage() {
  const { id } = useParams()
  const { addToCart } = useCart()
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist()
  const { toast } = useToast()

  // State for product options
  const [quantity, setQuantity] = useState(1)
  const [selectedColor, setSelectedColor] = useState(mockProduct.colors[0])
  const [selectedSize, setSelectedSize] = useState(mockProduct.sizes[2])
  const [isWishlisted, setIsWishlisted] = useState(isInWishlist(mockProduct.id))
  const [showDescription, setShowDescription] = useState(true)
  const [showFeatures, setShowFeatures] = useState(false)
  const [showReviews, setShowReviews] = useState(false)

  const handleAddToCart = () => {
    addToCart(
      {
        ...mockProduct,
        id: `${mockProduct.id}-${selectedColor.code}-${selectedSize}`,
      },
      quantity,
    )

    toast({
      title: "Produto adicionado ao carrinho",
      description: `${mockProduct.name} foi adicionado ao seu carrinho.`,
    })
  }

  const handleToggleWishlist = () => {
    if (isWishlisted) {
      removeFromWishlist(mockProduct.id)
      setIsWishlisted(false)
      toast({
        title: "Produto removido dos favoritos",
        description: `${mockProduct.name} foi removido dos seus favoritos.`,
      })
    } else {
      addToWishlist(mockProduct)
      setIsWishlisted(true)
      toast({
        title: "Produto adicionado aos favoritos",
        description: `${mockProduct.name} foi adicionado aos seus favoritos.`,
      })
    }
  }

  const increaseQuantity = () => {
    if (quantity < mockProduct.stock) {
      setQuantity(quantity + 1)
    }
  }

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Product Images */}
        <div className="lg:w-1/2">
          <div className="sticky top-24">
            <div className="relative aspect-square rounded-lg overflow-hidden mb-4">
              <Image
                src={selectedColor.image || "/placeholder.svg"}
                alt={mockProduct.name}
                fill
                className="object-cover"
                priority
              />
              {mockProduct.discount && mockProduct.discount > 0 && (
                <div className="absolute top-4 left-4 bg-red-600 text-white px-2 py-1 rounded-md text-sm font-medium">
                  -{mockProduct.discount}%
                </div>
              )}
            </div>

            <div className="grid grid-cols-4 gap-2">
              {mockProduct.colors.map((color) => (
                <button
                  key={color.code}
                  onClick={() => setSelectedColor(color)}
                  className={`relative aspect-square rounded-md overflow-hidden border-2 ${
                    selectedColor.code === color.code ? "border-purple-600" : "border-transparent"
                  }`}
                  aria-label={`Cor: ${color.name}`}
                >
                  <Image src={color.image || "/placeholder.svg"} alt={color.name} fill className="object-cover" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Product Info */}
        <div className="lg:w-1/2">
          <div className="mb-2">
            <Link href={`/marca/${mockProduct.brand.toLowerCase()}`} className="text-purple-600 hover:underline">
              {mockProduct.brand}
            </Link>
          </div>

          <h1 className="text-3xl font-bold text-gray-900 mb-4">{mockProduct.name}</h1>

          <div className="flex items-center mb-4">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <svg
                  key={i}
                  className={`w-5 h-5 ${i < Math.floor(mockProduct.rating) ? "text-yellow-400" : "text-gray-300"}`}
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
              <span className="ml-2 text-gray-600">
                {mockProduct.rating} ({mockProduct.reviewCount} avaliações)
              </span>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex items-center gap-3">
              {mockProduct.originalPrice && mockProduct.originalPrice > mockProduct.price ? (
                <>
                  <span className="text-3xl font-bold text-gray-900">{formatCurrency(mockProduct.price)}</span>
                  <span className="text-lg text-gray-500 line-through">
                    {formatCurrency(mockProduct.originalPrice)}
                  </span>
                </>
              ) : (
                <span className="text-3xl font-bold text-gray-900">{formatCurrency(mockProduct.price)}</span>
              )}
            </div>
            <p className="text-green-600 mt-1">Em estoque: {mockProduct.stock} unidades</p>
          </div>

          {/* Color Selection */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Cor: {selectedColor.name}</h3>
            <div className="flex flex-wrap gap-2">
              {mockProduct.colors.map((color) => (
                <button
                  key={color.code}
                  onClick={() => setSelectedColor(color)}
                  className={`w-8 h-8 rounded-full border ${
                    selectedColor.code === color.code ? "ring-2 ring-offset-2 ring-purple-600" : "border-gray-300"
                  }`}
                  style={{ backgroundColor: color.code }}
                  aria-label={`Cor: ${color.name}`}
                />
              ))}
            </div>
          </div>

          {/* Size Selection */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Tamanho</h3>
            <div className="flex flex-wrap gap-2">
              {mockProduct.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`px-3 py-1 border rounded-md ${
                    selectedSize === size
                      ? "bg-purple-600 text-white border-purple-600"
                      : "border-gray-300 text-gray-700 hover:border-purple-600"
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity and Add to Cart */}
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center border border-gray-300 rounded-md">
              <button
                onClick={decreaseQuantity}
                className="px-3 py-2 text-gray-600 hover:bg-gray-100"
                aria-label="Diminuir quantidade"
              >
                <ChevronDown className="h-4 w-4" />
              </button>
              <span className="px-4 py-2 text-gray-900 font-medium">{quantity}</span>
              <button
                onClick={increaseQuantity}
                className="px-3 py-2 text-gray-600 hover:bg-gray-100"
                aria-label="Aumentar quantidade"
              >
                <ChevronUp className="h-4 w-4" />
              </button>
            </div>

            <Button onClick={handleAddToCart} className="flex-1 bg-purple-600 hover:bg-purple-700">
              <ShoppingCart className="h-5 w-5 mr-2" />
              Adicionar ao Carrinho
            </Button>
          </div>

          {/* Buy Now Button */}
          <div className="mb-6">
            <Button onClick={handleAddToCart} className="w-full bg-green-600 hover:bg-green-700 text-lg py-6">
              Comprar Agora
            </Button>
          </div>

          {/* Virtual Try-On */}
          <div className="mb-8">
            <Button variant="outline" className="w-full">
              Experimentar Virtualmente
            </Button>
          </div>

          {/* Product Details */}
          <div className="border-t border-gray-200 pt-6">
            <button
              onClick={() => setShowDescription(!showDescription)}
              className="flex items-center justify-between w-full py-3 text-left"
            >
              <h3 className="text-lg font-medium text-gray-900">Descrição</h3>
              <ChevronDown className={`h-5 w-5 transition-transform ${showDescription ? "rotate-180" : ""}`} />
            </button>
            {showDescription && (
              <div className="pb-6 text-gray-700">
                <p>{mockProduct.description}</p>
              </div>
            )}

            <div className="border-t border-gray-200">
              <button
                onClick={() => setShowFeatures(!showFeatures)}
                className="flex items-center justify-between w-full py-3 text-left"
              >
                <h3 className="text-lg font-medium text-gray-900">Características</h3>
                <ChevronDown className={`h-5 w-5 transition-transform ${showFeatures ? "rotate-180" : ""}`} />
              </button>
              {showFeatures && (
                <div className="pb-6">
                  <ul className="list-disc pl-5 text-gray-700 space-y-2">
                    {mockProduct.features.map((feature, index) => (
                      <li key={index}>{feature}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="border-t border-gray-200">
              <button
                onClick={() => setShowReviews(!showReviews)}
                className="flex items-center justify-between w-full py-3 text-left"
              >
                <h3 className="text-lg font-medium text-gray-900">Avaliações</h3>
                <ChevronDown className={`h-5 w-5 transition-transform ${showReviews ? "rotate-180" : ""}`} />
              </button>
              {showReviews && (
                <div className="pb-6">
                  <p className="text-gray-700">
                    Este produto tem {mockProduct.reviewCount} avaliações com uma média de {mockProduct.rating}{" "}
                    estrelas.
                  </p>
                  <Button variant="link" className="p-0 text-purple-600 mt-2">
                    Ver todas as avaliações
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <section className="mt-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Produtos Relacionados</h2>
        <ProductGrid category={mockProduct.category} limit={4} />
      </section>
    </div>
  )
}

