"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/components/ui/use-toast"
import {
  Package,
  Heart,
  MessageSquare,
  Tag,
  User,
  LogOut,
  Eye,
  EyeOff,
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Truck,
  ArrowRight,
} from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function AccountPage() {
  const { user, logout } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  // Profile state
  const [name, setName] = useState(user?.name || "")
  const [email, setEmail] = useState(user?.email || "")
  const [phone, setPhone] = useState("(11) 98765-4321")
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)

  // Address state
  const [address, setAddress] = useState({
    street: "Av. Paulista",
    number: "1000",
    complement: "Apto 123",
    neighborhood: "Bela Vista",
    city: "São Paulo",
    state: "SP",
    zipCode: "01310-100",
  })

  // Dialog states
  const [isOrderDialogOpen, setIsOrderDialogOpen] = useState(false)
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [isMessageDialogOpen, setIsMessageDialogOpen] = useState(false)
  const [selectedMessage, setSelectedMessage] = useState<any>(null)

  // Mock orders
  const orders = [
    {
      id: "ORD123456",
      date: "15/04/2023",
      status: "delivered",
      statusLabel: "Entregue",
      total: 799.8,
      items: [
        {
          id: "1",
          name: "Óculos de Sol Ray-Ban Aviator",
          brand: "Ray-Ban",
          price: 599.9,
          quantity: 1,
          image:
            "https://images.unsplash.com/photo-1572635196237-14b3f281503f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
        },
        {
          id: "2",
          name: "Óculos de Grau Oakley Crosslink",
          brand: "Oakley",
          price: 199.9,
          quantity: 1,
          image:
            "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
        },
      ],
      shipping: {
        method: "standard",
        price: 15.9,
        address: "Av. Paulista, 1000, Apto 123, Bela Vista, São Paulo - SP, 01310-100",
        tracking: "BR123456789",
      },
      payment: {
        method: "credit-card",
        card: "**** **** **** 1234",
        installments: "2x de R$ 399,90",
      },
      timeline: [
        { date: "15/04/2023 10:30", status: "Pedido realizado" },
        { date: "15/04/2023 14:45", status: "Pagamento aprovado" },
        { date: "16/04/2023 09:15", status: "Em separação" },
        { date: "16/04/2023 16:30", status: "Enviado" },
        { date: "20/04/2023 11:20", status: "Entregue" },
      ],
    },
    {
      id: "ORD123457",
      date: "02/05/2023",
      status: "shipped",
      statusLabel: "Em trânsito",
      total: 349.9,
      items: [
        {
          id: "3",
          name: "Lentes de Contato Coloridas Solotica",
          brand: "Solotica",
          price: 149.9,
          quantity: 1,
          image:
            "https://images.pexels.com/photos/5752287/pexels-photo-5752287.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
        },
        {
          id: "6",
          name: "Lentes de Contato Acuvue Oasys",
          brand: "Acuvue",
          price: 179.9,
          quantity: 1,
          image:
            "https://images.pexels.com/photos/7760779/pexels-photo-7760779.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
        },
      ],
      shipping: {
        method: "express",
        price: 25.9,
        address: "Av. Paulista, 1000, Apto 123, Bela Vista, São Paulo - SP, 01310-100",
        tracking: "BR987654321",
      },
      payment: {
        method: "pix",
        details: "Pagamento via PIX",
      },
      timeline: [
        { date: "02/05/2023 14:20", status: "Pedido realizado" },
        { date: "02/05/2023 14:25", status: "Pagamento aprovado" },
        { date: "03/05/2023 10:30", status: "Em separação" },
        { date: "03/05/2023 15:45", status: "Enviado" },
      ],
    },
  ]

  // Mock messages
  const messages = [
    {
      id: "MSG001",
      date: "10/04/2023",
      subject: "Dúvida sobre lentes",
      status: "answered",
      statusLabel: "Respondida",
      conversation: [
        {
          sender: "client",
          message:
            "Olá, gostaria de saber se as lentes de contato coloridas Solotica são confortáveis para uso diário?",
          timestamp: "10/04/2023 14:30",
        },
        {
          sender: "store",
          message:
            "Olá! Sim, as lentes Solotica são desenvolvidas para uso diário confortável. Elas possuem alta permeabilidade de oxigênio, o que as torna confortáveis mesmo para uso prolongado. Recomendamos seguir as orientações do seu oftalmologista quanto ao tempo máximo de uso diário.",
          timestamp: "10/04/2023 15:45",
        },
        {
          sender: "client",
          message: "Obrigado pela informação! E qual é a durabilidade dessas lentes?",
          timestamp: "10/04/2023 16:20",
        },
        {
          sender: "store",
          message:
            "As lentes Solotica que vendemos são mensais, ou seja, têm duração de até 30 dias após abertas. É importante seguir as instruções de limpeza e armazenamento para garantir a durabilidade e, principalmente, a segurança no uso. Posso ajudar com mais alguma informação?",
          timestamp: "10/04/2023 17:05",
        },
        {
          sender: "client",
          message: "Perfeito! Vou fazer o pedido então. Muito obrigado pela atenção.",
          timestamp: "10/04/2023 17:30",
        },
      ],
    },
    {
      id: "MSG002",
      date: "05/05/2023",
      subject: "Problema com pedido",
      status: "open",
      statusLabel: "Aberta",
      conversation: [
        {
          sender: "client",
          message:
            "Olá, fiz um pedido de óculos de sol (pedido #ORD123456) mas recebi o modelo errado. Como posso proceder para fazer a troca?",
          timestamp: "05/05/2023 09:15",
        },
        {
          sender: "store",
          message:
            "Olá! Lamentamos pelo inconveniente. Vamos verificar o que aconteceu com seu pedido. Pode nos informar qual modelo você solicitou e qual recebeu? Também seria útil se pudesse enviar uma foto do produto recebido.",
          timestamp: "05/05/2023 10:30",
        },
        {
          sender: "client",
          message:
            "Solicitei o modelo Ray-Ban Aviator Classic em dourado, mas recebi o modelo em preto. Estou enviando a foto do produto recebido.",
          timestamp: "05/05/2023 11:45",
        },
      ],
    },
  ]

  // Mock coupons
  const coupons = [
    {
      id: "COUPON10",
      discount: "10% OFF",
      validUntil: "30/06/2023",
      status: "Válido",
      description: "10% de desconto em óculos de sol",
    },
    {
      id: "WELCOME15",
      discount: "15% OFF",
      validUntil: "31/12/2023",
      status: "Válido",
      description: "15% de desconto na primeira compra",
    },
  ]

  if (!user) {
    router.push("/login")
    return null
  }

  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault()

    if (newPassword && newPassword !== confirmPassword) {
      toast({
        title: "Senhas não conferem",
        description: "A nova senha e a confirmação não são iguais.",
        variant: "destructive",
      })
      return
    }

    setIsUpdating(true)

    // Simulate API call
    setTimeout(() => {
      setIsUpdating(false)
      toast({
        title: "Perfil atualizado",
        description: "Suas informações foram atualizadas com sucesso.",
      })
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
    }, 1000)
  }

  const handleUpdateAddress = (e: React.FormEvent) => {
    e.preventDefault()

    setIsUpdating(true)

    // Simulate API call
    setTimeout(() => {
      setIsUpdating(false)
      toast({
        title: "Endereço atualizado",
        description: "Seu endereço foi atualizado com sucesso.",
      })
    }, 1000)
  }

  const handleLogout = () => {
    logout()
    router.push("/")
    toast({
      title: "Logout realizado",
      description: "Você saiu da sua conta com sucesso.",
    })
  }

  const handleViewOrder = (order: any) => {
    setSelectedOrder(order)
    setIsOrderDialogOpen(true)
  }

  const handleViewMessage = (message: any) => {
    setSelectedMessage(message)
    setIsMessageDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            <Clock className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        )
      case "processing":
        return (
          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            <Package className="h-3 w-3 mr-1" />
            Em processamento
          </Badge>
        )
      case "shipped":
        return (
          <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">
            <Truck className="h-3 w-3 mr-1" />
            Enviado
          </Badge>
        )
      case "delivered":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            <CheckCircle className="h-3 w-3 mr-1" />
            Entregue
          </Badge>
        )
      case "cancelled":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            <XCircle className="h-3 w-3 mr-1" />
            Cancelado
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getMessageStatusBadge = (status: string) => {
    switch (status) {
      case "answered":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            <CheckCircle className="h-3 w-3 mr-1" />
            Respondida
          </Badge>
        )
      case "open":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            <Clock className="h-3 w-3 mr-1" />
            Aberta
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <div className="md:w-1/4">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="relative w-16 h-16 rounded-full overflow-hidden">
                  <Image
                    src={user.avatar || "/placeholder.svg?height=100&width=100"}
                    alt={user.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div>
                  <CardTitle>{user.name}</CardTitle>
                  <CardDescription>{user.email}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Button
                variant="outline"
                className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 mt-4"
                onClick={handleLogout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Sair da conta
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="md:w-3/4">
          <Tabs defaultValue="orders">
            <TabsList className="grid grid-cols-2 md:grid-cols-5 mb-8">
              <TabsTrigger value="orders">
                <Package className="h-4 w-4 mr-2" />
                <span className="hidden md:inline">Pedidos</span>
              </TabsTrigger>
              <TabsTrigger value="wishlist">
                <Heart className="h-4 w-4 mr-2" />
                <span className="hidden md:inline">Favoritos</span>
              </TabsTrigger>
              <TabsTrigger value="messages">
                <MessageSquare className="h-4 w-4 mr-2" />
                <span className="hidden md:inline">Mensagens</span>
              </TabsTrigger>
              <TabsTrigger value="coupons">
                <Tag className="h-4 w-4 mr-2" />
                <span className="hidden md:inline">Cupons</span>
              </TabsTrigger>
              <TabsTrigger value="profile">
                <User className="h-4 w-4 mr-2" />
                <span className="hidden md:inline">Perfil</span>
              </TabsTrigger>
            </TabsList>

            {/* Orders Tab */}
            <TabsContent value="orders">
              <Card>
                <CardHeader>
                  <CardTitle>Meus Pedidos</CardTitle>
                  <CardDescription>Acompanhe o status dos seus pedidos e veja o histórico de compras.</CardDescription>
                </CardHeader>
                <CardContent>
                  {orders.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b border-gray-200">
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Pedido</th>
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Data</th>
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Total</th>
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Ações</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orders.map((order) => (
                            <tr key={order.id} className="border-b border-gray-200">
                              <td className="py-3 px-4 text-gray-900">{order.id}</td>
                              <td className="py-3 px-4 text-gray-700">{order.date}</td>
                              <td className="py-3 px-4">{getStatusBadge(order.status)}</td>
                              <td className="py-3 px-4 text-gray-900">R$ {order.total.toFixed(2)}</td>
                              <td className="py-3 px-4">
                                <Button
                                  variant="link"
                                  className="h-auto p-0 text-purple-600"
                                  onClick={() => handleViewOrder(order)}
                                >
                                  Detalhes
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500">Você ainda não fez nenhum pedido.</p>
                      <Button className="mt-4 bg-purple-600 hover:bg-purple-700">Começar a comprar</Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Wishlist Tab */}
            <TabsContent value="wishlist">
              <Card>
                <CardHeader>
                  <CardTitle>Meus Favoritos</CardTitle>
                  <CardDescription>Veja os produtos que você salvou como favoritos.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <p className="text-gray-500">Você ainda não adicionou produtos aos favoritos.</p>
                    <Button className="mt-4 bg-purple-600 hover:bg-purple-700">Explorar produtos</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Messages Tab */}
            <TabsContent value="messages">
              <Card>
                <CardHeader>
                  <CardTitle>Minhas Mensagens</CardTitle>
                  <CardDescription>Veja suas mensagens e tire dúvidas com nossa equipe.</CardDescription>
                </CardHeader>
                <CardContent>
                  {messages.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b border-gray-200">
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Assunto</th>
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Data</th>
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                            <th className="py-3 px-4 text-left font-medium text-gray-700">Ações</th>
                          </tr>
                        </thead>
                        <tbody>
                          {messages.map((message) => (
                            <tr key={message.id} className="border-b border-gray-200">
                              <td className="py-3 px-4 text-gray-900">{message.subject}</td>
                              <td className="py-3 px-4 text-gray-700">{message.date}</td>
                              <td className="py-3 px-4">{getMessageStatusBadge(message.status)}</td>
                              <td className="py-3 px-4">
                                <Button
                                  variant="link"
                                  className="h-auto p-0 text-purple-600"
                                  onClick={() => handleViewMessage(message)}
                                >
                                  Ver mensagem
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500">Você não tem mensagens.</p>
                      <Button className="mt-4 bg-purple-600 hover:bg-purple-700">Enviar mensagem</Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Coupons Tab */}
            <TabsContent value="coupons">
              <Card>
                <CardHeader>
                  <CardTitle>Meus Cupons</CardTitle>
                  <CardDescription>Veja os cupons de desconto disponíveis para você.</CardDescription>
                </CardHeader>
                <CardContent>
                  {coupons.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {coupons.map((coupon) => (
                        <div key={coupon.id} className="border border-gray-200 rounded-lg p-4 bg-white">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-bold text-lg text-gray-900">{coupon.discount}</h3>
                              <p className="text-sm text-gray-700 mt-1">{coupon.description}</p>
                              <p className="text-xs text-gray-500 mt-2">Válido até: {coupon.validUntil}</p>
                            </div>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              {coupon.status}
                            </span>
                          </div>
                          <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between items-center">
                            <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">{coupon.id}</code>
                            <Button variant="outline" size="sm">
                              Copiar código
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500">Você não tem cupons disponíveis.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Profile Tab */}
            <TabsContent value="profile">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Personal Information */}
                <Card>
                  <CardHeader>
                    <CardTitle>Informações Pessoais</CardTitle>
                    <CardDescription>Atualize suas informações pessoais e senha.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleUpdateProfile}>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="name">Nome Completo</Label>
                          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
                        </div>

                        <div>
                          <Label htmlFor="email">E-mail</Label>
                          <Input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                          />
                        </div>

                        <div>
                          <Label htmlFor="phone">Telefone</Label>
                          <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
                        </div>

                        <div className="pt-4 border-t border-gray-200">
                          <h3 className="font-medium text-gray-900 mb-4">Alterar Senha</h3>

                          <div className="space-y-4">
                            <div>
                              <Label htmlFor="current-password">Senha Atual</Label>
                              <div className="relative">
                                <Input
                                  id="current-password"
                                  type={showPassword ? "text" : "password"}
                                  value={currentPassword}
                                  onChange={(e) => setCurrentPassword(e.target.value)}
                                />
                                <button
                                  type="button"
                                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                                  onClick={() => setShowPassword(!showPassword)}
                                  aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                                >
                                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                                </button>
                              </div>
                            </div>

                            <div>
                              <Label htmlFor="new-password">Nova Senha</Label>
                              <Input
                                id="new-password"
                                type={showPassword ? "text" : "password"}
                                value={newPassword}
                                onChange={(e) => setNewPassword(e.target.value)}
                              />
                            </div>

                            <div>
                              <Label htmlFor="confirm-password">Confirmar Nova Senha</Label>
                              <Input
                                id="confirm-password"
                                type={showPassword ? "text" : "password"}
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                              />
                            </div>
                          </div>
                        </div>

                        <Button
                          type="submit"
                          className="w-full bg-purple-600 hover:bg-purple-700"
                          disabled={isUpdating}
                        >
                          {isUpdating ? "Salvando..." : "Salvar Alterações"}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>

                {/* Address */}
                <Card>
                  <CardHeader>
                    <CardTitle>Endereço</CardTitle>
                    <CardDescription>Atualize seu endereço de entrega.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleUpdateAddress}>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="zipCode">CEP</Label>
                          <Input
                            id="zipCode"
                            value={address.zipCode}
                            onChange={(e) => setAddress({ ...address, zipCode: e.target.value })}
                            required
                          />
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                          <div className="col-span-2">
                            <Label htmlFor="street">Rua</Label>
                            <Input
                              id="street"
                              value={address.street}
                              onChange={(e) => setAddress({ ...address, street: e.target.value })}
                              required
                            />
                          </div>

                          <div>
                            <Label htmlFor="number">Número</Label>
                            <Input
                              id="number"
                              value={address.number}
                              onChange={(e) => setAddress({ ...address, number: e.target.value })}
                              required
                            />
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="complement">Complemento</Label>
                          <Input
                            id="complement"
                            value={address.complement}
                            onChange={(e) => setAddress({ ...address, complement: e.target.value })}
                          />
                        </div>

                        <div>
                          <Label htmlFor="neighborhood">Bairro</Label>
                          <Input
                            id="neighborhood"
                            value={address.neighborhood}
                            onChange={(e) => setAddress({ ...address, neighborhood: e.target.value })}
                            required
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="city">Cidade</Label>
                            <Input
                              id="city"
                              value={address.city}
                              onChange={(e) => setAddress({ ...address, city: e.target.value })}
                              required
                            />
                          </div>

                          <div>
                            <Label htmlFor="state">Estado</Label>
                            <Input
                              id="state"
                              value={address.state}
                              onChange={(e) => setAddress({ ...address, state: e.target.value })}
                              required
                            />
                          </div>
                        </div>

                        <Button
                          type="submit"
                          className="w-full bg-purple-600 hover:bg-purple-700"
                          disabled={isUpdating}
                        >
                          {isUpdating ? "Salvando..." : "Salvar Endereço"}
                        </Button>
                      </div>
                    </form>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={isOrderDialogOpen} onOpenChange={setIsOrderDialogOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Detalhes do Pedido #{selectedOrder.id}</DialogTitle>
              <DialogDescription>
                Pedido realizado em {selectedOrder.date} • {getStatusBadge(selectedOrder.status)}
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Order Items */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Itens do Pedido</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {selectedOrder.items.map((item: any) => (
                      <div key={item.id} className="flex gap-4 pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                        <div className="relative w-16 h-16 flex-shrink-0">
                          <Image
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            fill
                            className="object-cover rounded-md"
                          />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{item.name}</h4>
                          <p className="text-sm text-gray-500">{item.brand}</p>
                          <div className="flex justify-between mt-1">
                            <span className="text-sm text-gray-700">Qtd: {item.quantity}</span>
                            <span className="font-medium text-gray-900">R$ {item.price.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Order Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Resumo do Pedido</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal</span>
                      <span className="text-gray-900">
                        R$ {(selectedOrder.total - selectedOrder.shipping.price).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">
                        Frete ({selectedOrder.shipping.method === "express" ? "Expresso" : "Padrão"})
                      </span>
                      <span className="text-gray-900">R$ {selectedOrder.shipping.price.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span>R$ {selectedOrder.total.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <h4 className="font-medium text-gray-900 mb-2">Método de Pagamento</h4>
                    <p className="text-gray-700">
                      {selectedOrder.payment.method === "credit-card" && (
                        <>
                          Cartão de Crédito: {selectedOrder.payment.card}
                          <br />
                          {selectedOrder.payment.installments}
                        </>
                      )}
                      {selectedOrder.payment.method === "pix" && "Pagamento via PIX"}
                      {selectedOrder.payment.method === "boleto" && "Boleto Bancário"}
                    </p>
                  </div>

                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <h4 className="font-medium text-gray-900 mb-2">Endereço de Entrega</h4>
                    <p className="text-gray-700">{selectedOrder.shipping.address}</p>
                  </div>

                  {selectedOrder.shipping.tracking && (
                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <h4 className="font-medium text-gray-900 mb-2">Rastreamento</h4>
                      <p className="text-gray-700">Código: {selectedOrder.shipping.tracking}</p>
                      <Button variant="outline" size="sm" className="mt-2">
                        Rastrear Pedido
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Order Timeline */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Histórico do Pedido</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="relative border-l border-gray-200 ml-3">
                  {selectedOrder.timeline.map((event: any, index: number) => (
                    <li key={index} className="mb-6 ml-6 last:mb-0">
                      <span className="absolute flex items-center justify-center w-6 h-6 bg-purple-100 rounded-full -left-3 ring-8 ring-white">
                        <Calendar className="w-3 h-3 text-purple-800" />
                      </span>
                      <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900">
                        {event.status}
                        {index === selectedOrder.timeline.length - 1 && (
                          <span className="bg-purple-100 text-purple-800 text-sm font-medium mr-2 px-2.5 py-0.5 rounded ml-3">
                            Atual
                          </span>
                        )}
                      </h3>
                      <time className="block mb-2 text-sm font-normal leading-none text-gray-500">{event.date}</time>
                    </li>
                  ))}
                </ol>
              </CardContent>
            </Card>

            <div className="flex justify-end mt-4">
              <Button variant="outline" onClick={() => setIsOrderDialogOpen(false)}>
                Fechar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Message Dialog */}
      {selectedMessage && (
        <Dialog open={isMessageDialogOpen} onOpenChange={setIsMessageDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>{selectedMessage.subject}</DialogTitle>
              <DialogDescription>
                Iniciada em {selectedMessage.date} • {getMessageStatusBadge(selectedMessage.status)}
              </DialogDescription>
            </DialogHeader>

            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {selectedMessage.conversation.map((msg: any, index: number) => (
                  <div key={index} className={`flex ${msg.sender === "client" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] rounded-lg p-4 ${
                        msg.sender === "client" ? "bg-purple-100 text-purple-900" : "bg-gray-100 text-gray-900"
                      }`}
                    >
                      <p className="text-sm">{msg.message}</p>
                      <p className="text-xs text-gray-500 mt-2 text-right">{msg.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {selectedMessage.status === "open" && (
              <div className="mt-4">
                <div className="relative">
                  <textarea
                    className="w-full border border-gray-300 rounded-md p-3 pr-24 min-h-[100px]"
                    placeholder="Digite sua resposta..."
                  />
                  <Button className="absolute bottom-3 right-3 bg-purple-600 hover:bg-purple-700" size="sm">
                    Enviar <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            <div className="flex justify-end mt-4">
              <Button variant="outline" onClick={() => setIsMessageDialogOpen(false)}>
                Fechar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

