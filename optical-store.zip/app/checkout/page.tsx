"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { CreditCard, Barcode, QrCode, ChevronRight, Check, AlertCircle, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCart } from "@/components/cart-provider"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"

export default function CheckoutPage() {
  const router = useRouter()
  const { cartItems, subtotal, clearCart } = useCart()
  const { user } = useAuth()
  const { toast } = useToast()

  // Shipping options
  const shippingOptions = [
    { id: "standard", name: "Padrão (5-7 dias úteis)", price: 15.9 },
    { id: "express", name: "Expresso (2-3 dias úteis)", price: 25.9 },
  ]

  // State
  const [activeStep, setActiveStep] = useState(1)
  const [shippingMethod, setShippingMethod] = useState(shippingOptions[0].id)
  const [paymentMethod, setPaymentMethod] = useState("credit-card")
  const [isProcessing, setIsProcessing] = useState(false)
  const [prescriptionFiles, setPrescriptionFiles] = useState<Record<string, File | null>>({})
  const [needsPrescription, setNeedsPrescription] = useState(false)

  // Form state
  const [shippingAddress, setShippingAddress] = useState({
    fullName: user?.name || "",
    street: "Av. Paulista",
    number: "1000",
    complement: "Apto 123",
    neighborhood: "Bela Vista",
    city: "São Paulo",
    state: "SP",
    zipCode: "01310-100",
    phone: "(11) 98765-4321",
  })

  const [creditCardInfo, setCreditCardInfo] = useState({
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
    installments: "1",
  })

  // Check if any product requires prescription
  useEffect(() => {
    const requiresPrescription = cartItems.some((item) => item.category === "oculos-de-grau")
    setNeedsPrescription(requiresPrescription)

    // Initialize prescription files state
    const initialPrescriptionFiles: Record<string, File | null> = {}
    cartItems.forEach((item) => {
      if (item.category === "oculos-de-grau") {
        initialPrescriptionFiles[item.id] = null
      }
    })
    setPrescriptionFiles(initialPrescriptionFiles)
  }, [cartItems])

  // Calculate totals
  const selectedShipping = shippingOptions.find((option) => option.id === shippingMethod)
  const shippingCost = selectedShipping ? selectedShipping.price : 0
  const total = subtotal + shippingCost

  const handleFileChange = (itemId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPrescriptionFiles((prev) => ({
        ...prev,
        [itemId]: e.target.files![0],
      }))
    }
  }

  const handleShippingAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setShippingAddress((prev) => ({ ...prev, [name]: value }))
  }

  const handleCreditCardChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setCreditCardInfo((prev) => ({ ...prev, [name]: value }))
  }

  const handleContinue = () => {
    if (activeStep === 1) {
      // Validate shipping address
      const requiredFields = ["fullName", "street", "number", "neighborhood", "city", "state", "zipCode", "phone"]
      const missingFields = requiredFields.filter((field) => !shippingAddress[field as keyof typeof shippingAddress])

      if (missingFields.length > 0) {
        toast({
          title: "Campos obrigatórios",
          description: "Por favor, preencha todos os campos obrigatórios.",
          variant: "destructive",
        })
        return
      }

      setActiveStep(2)
    } else if (activeStep === 2) {
      // Validate prescription if needed
      if (needsPrescription) {
        const missingPrescriptions = Object.entries(prescriptionFiles)
          .filter(([_, file]) => !file)
          .map(([itemId]) => itemId)

        if (missingPrescriptions.length > 0) {
          toast({
            title: "Receita médica necessária",
            description: "Por favor, anexe todas as receitas médicas necessárias para continuar.",
            variant: "destructive",
          })
          return
        }
      }

      setActiveStep(3)
    } else if (activeStep === 3) {
      // Validate payment info
      if (paymentMethod === "credit-card") {
        const requiredFields = ["cardNumber", "cardName", "expiryDate", "cvv"]
        const missingFields = requiredFields.filter((field) => !creditCardInfo[field as keyof typeof creditCardInfo])

        if (missingFields.length > 0) {
          toast({
            title: "Campos obrigatórios",
            description: "Por favor, preencha todos os campos do cartão de crédito.",
            variant: "destructive",
          })
          return
        }

        // Validate card number format
        if (creditCardInfo.cardNumber.replace(/\s/g, "").length !== 16) {
          toast({
            title: "Número de cartão inválido",
            description: "Por favor, insira um número de cartão válido.",
            variant: "destructive",
          })
          return
        }
      }

      handlePlaceOrder()
    }
  }

  const handlePlaceOrder = () => {
    setIsProcessing(true)

    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false)
      clearCart()

      toast({
        title: "Pedido realizado com sucesso!",
        description: "Você receberá um e-mail com os detalhes do seu pedido.",
      })

      router.push("/pedido-confirmado")
    }, 2000)
  }

  if (cartItems.length === 0) {
    router.push("/cart")
    return null
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Finalizar Compra</h1>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Main Content */}
        <div className="lg:w-2/3">
          <div className="mb-8">
            <div className="flex items-center mb-6">
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  activeStep >= 1 ? "bg-purple-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                1
              </div>
              <div className="h-1 w-12 mx-2 bg-gray-200">
                <div className={`h-full ${activeStep >= 2 ? "bg-purple-600" : "bg-gray-200"}`}></div>
              </div>
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  activeStep >= 2 ? "bg-purple-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                2
              </div>
              <div className="h-1 w-12 mx-2 bg-gray-200">
                <div className={`h-full ${activeStep >= 3 ? "bg-purple-600" : "bg-gray-200"}`}></div>
              </div>
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full ${
                  activeStep >= 3 ? "bg-purple-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                3
              </div>
            </div>
          </div>

          {/* Step 1: Shipping Address */}
          {activeStep === 1 && (
            <Card>
              <CardHeader>
                <CardTitle>Endereço de Entrega</CardTitle>
                <CardDescription>Informe o endereço onde deseja receber seu pedido.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <Label htmlFor="fullName">Nome Completo *</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={shippingAddress.fullName}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="zipCode">CEP *</Label>
                    <Input
                      id="zipCode"
                      name="zipCode"
                      value={shippingAddress.zipCode}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Telefone *</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={shippingAddress.phone}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="street">Rua/Avenida *</Label>
                    <Input
                      id="street"
                      name="street"
                      value={shippingAddress.street}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="number">Número *</Label>
                    <Input
                      id="number"
                      name="number"
                      value={shippingAddress.number}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="complement">Complemento</Label>
                    <Input
                      id="complement"
                      name="complement"
                      value={shippingAddress.complement}
                      onChange={handleShippingAddressChange}
                    />
                  </div>

                  <div>
                    <Label htmlFor="neighborhood">Bairro *</Label>
                    <Input
                      id="neighborhood"
                      name="neighborhood"
                      value={shippingAddress.neighborhood}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="city">Cidade *</Label>
                    <Input
                      id="city"
                      name="city"
                      value={shippingAddress.city}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="state">Estado *</Label>
                    <Input
                      id="state"
                      name="state"
                      value={shippingAddress.state}
                      onChange={handleShippingAddressChange}
                      required
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button onClick={handleContinue} className="bg-purple-600 hover:bg-purple-700">
                  Continuar
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          )}

          {/* Step 2: Shipping Method & Prescription */}
          {activeStep === 2 && (
            <Card>
              <CardHeader>
                <CardTitle>Método de Envio</CardTitle>
                <CardDescription>Escolha como deseja receber seu pedido.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <RadioGroup value={shippingMethod} onValueChange={setShippingMethod} className="space-y-3">
                    {shippingOptions.map((option) => (
                      <div
                        key={option.id}
                        className="flex items-center justify-between space-x-2 border p-4 rounded-md"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value={option.id} id={option.id} />
                          <Label htmlFor={option.id} className="font-normal cursor-pointer">
                            {option.name}
                          </Label>
                        </div>
                        <span className="font-medium">R$ {option.price.toFixed(2)}</span>
                      </div>
                    ))}
                  </RadioGroup>

                  {needsPrescription && (
                    <div className="mt-8 border border-gray-200 rounded-md p-4">
                      <div className="flex items-start mb-4">
                        <AlertCircle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium text-gray-900">Receitas Médicas Necessárias</h3>
                          <p className="text-gray-600 text-sm mt-1">
                            Para óculos de grau, é necessário anexar uma receita médica válida para cada produto.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-6">
                        {cartItems
                          .filter((item) => item.category === "oculos-de-grau")
                          .map((item) => (
                            <div key={item.id} className="border-2 border-dashed border-gray-300 rounded-md p-4">
                              <div className="flex items-center mb-3">
                                <div className="relative w-12 h-12 flex-shrink-0 mr-3">
                                  <Image
                                    src={item.image || "/placeholder.svg"}
                                    alt={item.name}
                                    fill
                                    className="object-cover rounded-md"
                                  />
                                </div>
                                <div>
                                  <h4 className="font-medium text-gray-900">{item.name}</h4>
                                  <p className="text-sm text-gray-500">{item.brand}</p>
                                </div>
                              </div>

                              {prescriptionFiles[item.id] ? (
                                <div className="flex flex-col items-center">
                                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 text-green-600 mb-2">
                                    <Check className="h-6 w-6" />
                                  </div>
                                  <p className="text-sm font-medium text-gray-900">
                                    {prescriptionFiles[item.id]?.name}
                                  </p>
                                  <p className="text-xs text-gray-500 mt-1">
                                    {prescriptionFiles[item.id] && (prescriptionFiles[item.id]!.size / 1024).toFixed(2)}{" "}
                                    KB
                                  </p>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="mt-3"
                                    onClick={() => setPrescriptionFiles((prev) => ({ ...prev, [item.id]: null }))}
                                  >
                                    Remover
                                  </Button>
                                </div>
                              ) : (
                                <>
                                  <div className="flex flex-col items-center">
                                    <FileText className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                                    <p className="text-sm text-gray-600 mb-2">
                                      Anexe a receita médica para este produto
                                    </p>
                                    <Label
                                      htmlFor={`prescription-${item.id}`}
                                      className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-purple-600 text-white hover:bg-purple-700 h-10 px-4 py-2 cursor-pointer"
                                    >
                                      Selecionar arquivo
                                    </Label>
                                    <Input
                                      id={`prescription-${item.id}`}
                                      type="file"
                                      accept=".jpg,.jpeg,.png,.pdf"
                                      className="hidden"
                                      onChange={(e) => handleFileChange(item.id, e)}
                                    />
                                    <p className="text-xs text-gray-500 mt-2">
                                      Formatos aceitos: JPG, PNG, PDF (máx. 5MB)
                                    </p>
                                  </div>
                                </>
                              )}
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setActiveStep(1)}>
                  Voltar
                </Button>
                <Button onClick={handleContinue} className="bg-purple-600 hover:bg-purple-700">
                  Continuar
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          )}

          {/* Step 3: Payment Method */}
          {activeStep === 3 && (
            <Card>
              <CardHeader>
                <CardTitle>Método de Pagamento</CardTitle>
                <CardDescription>Escolha como deseja pagar pelo seu pedido.</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="credit-card" onValueChange={setPaymentMethod}>
                  <TabsList className="grid grid-cols-3 mb-6">
                    <TabsTrigger value="credit-card">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Cartão de Crédito
                    </TabsTrigger>
                    <TabsTrigger value="boleto">
                      <Barcode className="h-4 w-4 mr-2" />
                      Boleto
                    </TabsTrigger>
                    <TabsTrigger value="pix">
                      <QrCode className="h-4 w-4 mr-2" />
                      PIX
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="credit-card">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="cardNumber">Número do Cartão *</Label>
                        <Input
                          id="cardNumber"
                          name="cardNumber"
                          placeholder="0000 0000 0000 0000"
                          value={creditCardInfo.cardNumber}
                          onChange={handleCreditCardChange}
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="cardName">Nome no Cartão *</Label>
                        <Input
                          id="cardName"
                          name="cardName"
                          placeholder="Como está impresso no cartão"
                          value={creditCardInfo.cardName}
                          onChange={handleCreditCardChange}
                          required
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="expiryDate">Data de Validade *</Label>
                          <Input
                            id="expiryDate"
                            name="expiryDate"
                            placeholder="MM/AA"
                            value={creditCardInfo.expiryDate}
                            onChange={handleCreditCardChange}
                            required
                          />
                        </div>

                        <div>
                          <Label htmlFor="cvv">CVV *</Label>
                          <Input
                            id="cvv"
                            name="cvv"
                            placeholder="123"
                            value={creditCardInfo.cvv}
                            onChange={handleCreditCardChange}
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="installments">Parcelas *</Label>
                        <select
                          id="installments"
                          name="installments"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          value={creditCardInfo.installments}
                          onChange={handleCreditCardChange}
                        >
                          <option value="1">1x de R$ {total.toFixed(2)} (sem juros)</option>
                          <option value="2">2x de R$ {(total / 2).toFixed(2)} (sem juros)</option>
                          <option value="3">3x de R$ {(total / 3).toFixed(2)} (sem juros)</option>
                          <option value="4">4x de R$ {(total / 4).toFixed(2)} (sem juros)</option>
                          <option value="5">5x de R$ {(total / 5).toFixed(2)} (sem juros)</option>
                          <option value="6">6x de R$ {(total / 6).toFixed(2)} (sem juros)</option>
                        </select>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="boleto">
                    <div className="text-center py-6 space-y-4">
                      <Barcode className="h-16 w-16 mx-auto text-gray-600" />
                      <div>
                        <h3 className="font-medium text-gray-900">Pagamento via Boleto Bancário</h3>
                        <p className="text-gray-600 text-sm mt-1">
                          Após a confirmação do pedido, você receberá o boleto por e-mail. O prazo de processamento é de
                          até 3 dias úteis após o pagamento.
                        </p>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="pix">
                    <div className="text-center py-6 space-y-4">
                      <QrCode className="h-16 w-16 mx-auto text-gray-600" />
                      <div>
                        <h3 className="font-medium text-gray-900">Pagamento via PIX</h3>
                        <p className="text-gray-600 text-sm mt-1">
                          Após a confirmação do pedido, você receberá um QR Code para pagamento. O pedido será
                          processado imediatamente após a confirmação do pagamento.
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setActiveStep(2)}>
                  Voltar
                </Button>
                <Button onClick={handleContinue} className="bg-purple-600 hover:bg-purple-700" disabled={isProcessing}>
                  {isProcessing ? "Processando..." : "Finalizar Pedido"}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>

        {/* Order Summary */}
        <div className="lg:w-1/3">
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Resumo do Pedido</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible defaultValue="items">
                <AccordionItem value="items">
                  <AccordionTrigger>Itens ({cartItems.length})</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 mt-2">
                      {cartItems.map((item) => (
                        <div key={item.id} className="flex gap-3">
                          <div className="relative w-16 h-16 flex-shrink-0">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-cover rounded-md"
                            />
                          </div>
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-gray-900 line-clamp-1">{item.name}</h4>
                            <p className="text-xs text-gray-500">{item.brand}</p>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-xs text-gray-500">Qtd: {item.quantity}</span>
                              <span className="text-sm font-medium text-gray-900">
                                R$ {(item.price * item.quantity).toFixed(2)}
                              </span>
                            </div>
                            {item.category === "oculos-de-grau" && (
                              <Badge className="mt-1 bg-purple-100 text-purple-800 hover:bg-purple-100">
                                Receita necessária
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>

              <div className="space-y-3 mt-6">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="text-gray-900">R$ {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Frete</span>
                  <span className="text-gray-900">R$ {shippingCost.toFixed(2)}</span>
                </div>
                <div className="border-t border-gray-200 pt-3 mt-3">
                  <div className="flex justify-between font-bold">
                    <span className="text-gray-900">Total</span>
                    <span className="text-gray-900">R$ {total.toFixed(2)}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Impostos inclusos</p>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <h4 className="font-medium text-gray-900 mb-2">Endereço de Entrega</h4>
                {activeStep > 1 ? (
                  <div className="text-sm text-gray-600">
                    <p>{shippingAddress.fullName}</p>
                    <p>
                      {shippingAddress.street}, {shippingAddress.number}
                    </p>
                    {shippingAddress.complement && <p>{shippingAddress.complement}</p>}
                    <p>{shippingAddress.neighborhood}</p>
                    <p>
                      {shippingAddress.city} - {shippingAddress.state}
                    </p>
                    <p>{shippingAddress.zipCode}</p>
                    <p>{shippingAddress.phone}</p>
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">O endereço de entrega será definido na próxima etapa.</p>
                )}
              </div>

              {activeStep > 2 && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h4 className="font-medium text-gray-900 mb-2">Método de Envio</h4>
                  <p className="text-sm text-gray-600">
                    {shippingOptions.find((option) => option.id === shippingMethod)?.name}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

