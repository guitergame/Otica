"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Trash2, ChevronDown, ChevronUp, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useCart } from "@/components/cart-provider"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/components/ui/use-toast"

export default function CartPage() {
  const { cartItems, removeFromCart, updateQuantity, clearCart, subtotal } = useCart()
  const { isAuthenticated } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const [couponCode, setCouponCode] = useState("")
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false)

  const shipping = 15.9
  const total = subtotal + shipping

  const handleApplyCoupon = () => {
    if (!couponCode) return

    setIsApplyingCoupon(true)

    // Simulate API call
    setTimeout(() => {
      setIsApplyingCoupon(false)
      toast({
        title: "Cupom inválido",
        description: "O cupom informado não é válido ou expirou.",
        variant: "destructive",
      })
    }, 1000)
  }

  const handleCheckout = () => {
    if (!isAuthenticated) {
      toast({
        title: "Faça login para continuar",
        description: "É necessário estar logado para finalizar a compra.",
      })
      router.push("/login?redirect=/checkout")
      return
    }

    router.push("/checkout")
  }

  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Seu Carrinho</h1>
        <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-sm border border-gray-200">
          <p className="text-gray-700 mb-6">Seu carrinho está vazio.</p>
          <Link href="/produtos">
            <Button className="bg-purple-600 hover:bg-purple-700">Continuar Comprando</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Seu Carrinho</h1>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Cart Items */}
        <div className="lg:w-2/3">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div className="hidden md:grid grid-cols-12 gap-4 p-4 bg-gray-50 border-b border-gray-200">
              <div className="col-span-6">
                <span className="font-medium text-gray-700">Produto</span>
              </div>
              <div className="col-span-2 text-center">
                <span className="font-medium text-gray-700">Preço</span>
              </div>
              <div className="col-span-2 text-center">
                <span className="font-medium text-gray-700">Quantidade</span>
              </div>
              <div className="col-span-2 text-center">
                <span className="font-medium text-gray-700">Total</span>
              </div>
            </div>

            {cartItems.map((item) => (
              <div key={item.id} className="border-b border-gray-200 last:border-0">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 p-4">
                  {/* Product */}
                  <div className="col-span-1 md:col-span-6 flex items-center gap-4">
                    <div className="relative w-20 h-20 flex-shrink-0">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        fill
                        className="object-cover rounded-md"
                      />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{item.name}</h3>
                      <p className="text-sm text-gray-500">{item.brand}</p>
                      {item.colors && item.colors.length > 0 && (
                        <div className="flex items-center gap-1 mt-1">
                          <span className="text-sm text-gray-500">Cor:</span>
                          <div
                            className="w-4 h-4 rounded-full border border-gray-300"
                            style={{ backgroundColor: item.colors[0] }}
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Price */}
                  <div className="col-span-1 md:col-span-2 flex md:justify-center items-center">
                    <div className="md:hidden font-medium text-gray-700 mr-2">Preço:</div>
                    <span className="text-gray-900">R$ {item.price.toFixed(2)}</span>
                  </div>

                  {/* Quantity */}
                  <div className="col-span-1 md:col-span-2 flex md:justify-center items-center">
                    <div className="md:hidden font-medium text-gray-700 mr-2">Quantidade:</div>
                    <div className="flex items-center border border-gray-300 rounded-md">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="px-2 py-1 text-gray-600 hover:bg-gray-100"
                        aria-label="Diminuir quantidade"
                      >
                        <ChevronDown className="h-4 w-4" />
                      </button>
                      <span className="px-3 py-1 text-gray-900 font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="px-2 py-1 text-gray-600 hover:bg-gray-100"
                        aria-label="Aumentar quantidade"
                      >
                        <ChevronUp className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Total */}
                  <div className="col-span-1 md:col-span-2 flex justify-between md:justify-center items-center">
                    <div className="md:hidden font-medium text-gray-700 mr-2">Total:</div>
                    <span className="font-medium text-gray-900">R$ {(item.price * item.quantity).toFixed(2)}</span>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-gray-500 hover:text-red-600 md:ml-4"
                      aria-label="Remover item"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}

            <div className="p-4 flex justify-between items-center bg-gray-50">
              <Button variant="outline" onClick={clearCart} className="text-gray-700">
                Limpar Carrinho
              </Button>

              <Link href="/produtos">
                <Button variant="outline" className="text-gray-700">
                  Continuar Comprando
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:w-1/3">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Resumo do Pedido</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-700">Subtotal</span>
                <span className="text-gray-900">R$ {subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">Frete</span>
                <span className="text-gray-900">R$ {shipping.toFixed(2)}</span>
              </div>
              <div className="border-t border-gray-200 pt-3 mt-3">
                <div className="flex justify-between font-bold">
                  <span className="text-gray-900">Total</span>
                  <span className="text-gray-900">R$ {total.toFixed(2)}</span>
                </div>
                <p className="text-sm text-gray-500 mt-1">Impostos inclusos</p>
              </div>
            </div>

            {/* Coupon */}
            <div className="mb-6">
              <label htmlFor="coupon" className="block text-sm font-medium text-gray-700 mb-2">
                Cupom de Desconto
              </label>
              <div className="flex gap-2">
                <Input
                  id="coupon"
                  type="text"
                  placeholder="Digite seu cupom"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1"
                />
                <Button
                  onClick={handleApplyCoupon}
                  disabled={isApplyingCoupon || !couponCode}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Aplicar
                </Button>
              </div>
            </div>

            <Button onClick={handleCheckout} className="w-full bg-purple-600 hover:bg-purple-700">
              Finalizar Compra
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

