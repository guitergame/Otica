"use client"

import { useEffect } from "react"
import Link from "next/link"
import { CheckCircle, Package, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function OrderConfirmedPage() {
  // Generate a random order number
  const orderNumber = `ORD-${Math.floor(Math.random() * 1000000)
    .toString()
    .padStart(6, "0")}`

  useEffect(() => {
    // Scroll to top on page load
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <div className="max-w-md mx-auto">
        <div className="flex justify-center mb-6">
          <div className="rounded-full bg-green-100 p-3">
            <CheckCircle className="h-16 w-16 text-green-600" />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-gray-900 mb-4">Pedido Confirmado!</h1>
        <p className="text-gray-600 mb-8">
          Seu pedido foi recebido e está sendo processado. Você receberá um e-mail com os detalhes do seu pedido.
        </p>

        <Card>
          <CardHeader>
            <CardTitle>Detalhes do Pedido</CardTitle>
            <CardDescription>
              Número do Pedido: <span className="font-medium">{orderNumber}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2 text-gray-600">
                <Package className="h-5 w-5" />
                <span>Seu pedido está sendo preparado</span>
              </div>

              <div className="text-sm text-gray-600">
                <p>Estimativa de entrega: 5-7 dias úteis</p>
                <p className="mt-1">Um e-mail de confirmação foi enviado para {"{seu@email.com}"}</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-2">
            <Link href="/minha-conta" className="w-full">
              <Button variant="outline" className="w-full">
                Acompanhar Pedido
              </Button>
            </Link>
            <Link href="/" className="w-full">
              <Button className="w-full bg-purple-600 hover:bg-purple-700">
                Continuar Comprando
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

