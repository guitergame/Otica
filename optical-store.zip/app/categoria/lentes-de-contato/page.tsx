"use client"

import { useState } from "react"
import Link from "next/link"
import { Filter, ChevronDown, ChevronUp, Eye, Star, Bookmark, Palette } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import ProductCard from "@/components/product-card"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for contact lenses
const contactLensesProducts = [
  {
    id: "lens-1",
    name: "Lentes de Contato Coloridas Solotica",
    brand: "Solotica",
    price: 149.9,
    image:
      "https://images.pexels.com/photos/5752287/pexels-photo-5752287.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#8B4513", "#228B22"],
    isNew: false,
  },
  {
    id: "lens-2",
    name: "Lentes de Contato Acuvue Oasys",
    brand: "Acuvue",
    price: 179.9,
    image:
      "https://images.pexels.com/photos/7760779/pexels-photo-7760779.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    isNew: true,
  },
  {
    id: "lens-3",
    name: "Lentes de Contato Coloridas Hidrocor",
    brand: "Hidrocor",
    price: 129.9,
    originalPrice: 149.9,
    discount: 13,
    image:
      "https://images.pexels.com/photos/8179216/pexels-photo-8179216.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#228B22", "#8B4513"],
    isNew: false,
  },
  {
    id: "lens-4",
    name: "Lentes de Contato Acuvue 2",
    brand: "Acuvue",
    price: 129.9,
    originalPrice: 159.9,
    discount: 19,
    image:
      "https://images.pexels.com/photos/8460290/pexels-photo-8460290.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    isNew: false,
  },
  {
    id: "lens-5",
    name: "Lentes de Contato Coloridas Natural Colors",
    brand: "Natural Colors",
    price: 119.9,
    image:
      "https://images.pexels.com/photos/7760916/pexels-photo-7760916.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#8B4513", "#228B22", "#808080"],
    isNew: true,
  },
  {
    id: "lens-6",
    name: "Lentes de Contato Biofinity",
    brand: "CooperVision",
    price: 199.9,
    originalPrice: 229.9,
    discount: 13,
    image:
      "https://images.pexels.com/photos/7760780/pexels-photo-7760780.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    isNew: false,
  },
  {
    id: "lens-7",
    name: "Lentes de Contato Air Optix",
    brand: "Alcon",
    price: 189.9,
    image:
      "https://images.pexels.com/photos/7760918/pexels-photo-7760918.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    isNew: false,
  },
  {
    id: "lens-8",
    name: "Lentes de Contato Coloridas FreshLook",
    brand: "Alcon",
    price: 159.9,
    originalPrice: 179.9,
    discount: 11,
    image:
      "https://images.pexels.com/photos/7760917/pexels-photo-7760917.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#8B4513", "#228B22", "#808080", "#000000"],
    isNew: false,
  },
  {
    id: "lens-9",
    name: "Lentes de Contato Dailies AquaComfort Plus",
    brand: "Alcon",
    price: 149.9,
    image:
      "https://images.pexels.com/photos/7760781/pexels-photo-7760781.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    isNew: true,
  },
  {
    id: "lens-10",
    name: "Lentes de Contato Coloridas Lunare",
    brand: "Lunare",
    price: 139.9,
    originalPrice: 159.9,
    discount: 13,
    image:
      "https://images.pexels.com/photos/8179217/pexels-photo-8179217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#8B4513", "#228B22", "#808080"],
    isNew: false,
  },
  {
    id: "lens-11",
    name: "Lentes de Contato Proclear",
    brand: "CooperVision",
    price: 179.9,
    image:
      "https://images.pexels.com/photos/7760782/pexels-photo-7760782.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    isNew: false,
  },
  {
    id: "lens-12",
    name: "Lentes de Contato Coloridas Anual",
    brand: "Optolentes",
    price: 169.9,
    originalPrice: 199.9,
    discount: 15,
    image:
      "https://images.pexels.com/photos/8179218/pexels-photo-8179218.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#8B4513", "#228B22", "#808080", "#000000"],
    isNew: false,
  },
]

const brands = [
  "Todas as marcas",
  "Solotica",
  "Acuvue",
  "Hidrocor",
  "Natural Colors",
  "CooperVision",
  "Alcon",
  "Lunare",
  "Optolentes",
]

const lensTypes = [
  { name: "Todos os tipos", icon: Eye },
  { name: "Coloridas", icon: Palette },
  { name: "Transparentes", icon: Eye },
  { name: "Descartáveis diárias", icon: Bookmark },
  { name: "Descartáveis quinzenais", icon: Bookmark },
  { name: "Descartáveis mensais", icon: Bookmark },
  { name: "Anuais", icon: Bookmark },
]

const lensColors = [
  { name: "Todas as cores", icon: Palette },
  { name: "Azul", icon: Palette },
  { name: "Verde", icon: Palette },
  { name: "Mel", icon: Palette },
  { name: "Cinza", icon: Palette },
  { name: "Preto", icon: Palette },
]

export default function ContactLensesPage() {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 250])
  const [selectedBrand, setSelectedBrand] = useState("Todas as marcas")
  const [selectedType, setSelectedType] = useState("Todos os tipos")
  const [selectedColor, setSelectedColor] = useState("Todas as cores")
  const [showDiscount, setShowDiscount] = useState(false)
  const [showNew, setShowNew] = useState(false)
  const [sortBy, setSortBy] = useState("relevance")

  // Filter products based on selected filters
  const filteredProducts = contactLensesProducts.filter((product) => {
    // Filter by price range
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false
    }

    // Filter by brand
    if (selectedBrand !== "Todas as marcas" && product.brand !== selectedBrand) {
      return false
    }

    // Filter by discount
    if (showDiscount && !product.discount) {
      return false
    }

    // Filter by new
    if (showNew && !product.isNew) {
      return false
    }

    return true
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return a.price - b.price
      case "price-desc":
        return b.price - a.price
      case "name-asc":
        return a.name.localeCompare(b.name)
      case "name-desc":
        return b.name.localeCompare(a.name)
      case "discount":
        const discountA = a.discount || 0
        const discountB = b.discount || 0
        return discountB - discountA
      default:
        return 0
    }
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col space-y-4">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-purple-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-900 font-medium">Lentes de Contato</span>
        </nav>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="md:block w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-24">
              <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filtros
              </h2>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Palette className="h-4 w-4 mr-2" />
                  Preço
                </h3>
                <Slider
                  defaultValue={[0, 250]}
                  max={250}
                  step={10}
                  value={priceRange}
                  onValueChange={(value) => setPriceRange(value as [number, number])}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>R$ {priceRange[0].toLocaleString("pt-BR")}</span>
                  <span>R$ {priceRange[1].toLocaleString("pt-BR")}</span>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Brands */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Star className="h-4 w-4 mr-2" />
                  Marcas
                </h3>
                <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                  <div className="space-y-2">
                    {brands.map((brand) => (
                      <div key={brand} className="flex items-center">
                        <RadioGroupItem value={brand} id={`brand-${brand}`} />
                        <Label htmlFor={`brand-${brand}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {brand}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Lens Type */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Eye className="h-4 w-4 mr-2" />
                  Tipo de Lente
                </h3>
                <RadioGroup value={selectedType} onValueChange={setSelectedType}>
                  <div className="space-y-2">
                    {lensTypes.map((type) => (
                      <div key={type.name} className="flex items-center">
                        <RadioGroupItem value={type.name} id={`type-${type.name}`} />
                        <Label
                          htmlFor={`type-${type.name}`}
                          className="ml-2 text-sm font-normal cursor-pointer flex items-center"
                        >
                          <type.icon className="h-4 w-4 mr-2" />
                          {type.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Lens Color */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Palette className="h-4 w-4 mr-2" />
                  Cor da Lente
                </h3>
                <RadioGroup value={selectedColor} onValueChange={setSelectedColor}>
                  <div className="space-y-2">
                    {lensColors.map((color) => (
                      <div key={color.name} className="flex items-center">
                        <RadioGroupItem value={color.name} id={`color-${color.name}`} />
                        <Label
                          htmlFor={`color-${color.name}`}
                          className="ml-2 text-sm font-normal cursor-pointer flex items-center"
                        >
                          <color.icon className="h-4 w-4 mr-2" />
                          {color.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Other Filters */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Outros Filtros</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox
                      id="discount"
                      checked={showDiscount}
                      onCheckedChange={(checked) => setShowDiscount(!!checked)}
                    />
                    <Label htmlFor="discount" className="ml-2 text-sm font-normal cursor-pointer">
                      Em promoção
                    </Label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="new" checked={showNew} onCheckedChange={(checked) => setShowNew(!!checked)} />
                    <Label htmlFor="new" className="ml-2 text-sm font-normal cursor-pointer">
                      Lançamentos
                    </Label>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setPriceRange([0, 250])
                  setSelectedBrand("Todas as marcas")
                  setSelectedType("Todos os tipos")
                  setSelectedColor("Todas as cores")
                  setShowDiscount(false)
                  setShowNew(false)
                }}
              >
                Limpar Filtros
              </Button>
            </div>
          </div>

          {/* Mobile Filters */}
          <div className="md:hidden mb-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center justify-center">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px] overflow-auto">
                <div className="py-4">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">Filtros</h2>

                  {/* Price Range */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Preço</h3>
                    <Slider
                      defaultValue={[0, 250]}
                      max={250}
                      step={10}
                      value={priceRange}
                      onValueChange={(value) => setPriceRange(value as [number, number])}
                      className="mb-2"
                    />
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>R$ {priceRange[0].toLocaleString("pt-BR")}</span>
                      <span>R$ {priceRange[1].toLocaleString("pt-BR")}</span>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Brands */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Marcas</h3>
                    <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                      <div className="space-y-2">
                        {brands.map((brand) => (
                          <div key={brand} className="flex items-center">
                            <RadioGroupItem value={brand} id={`mobile-brand-${brand}`} />
                            <Label
                              htmlFor={`mobile-brand-${brand}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {brand}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator className="my-4" />

                  {/* Lens Type */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Tipo de Lente</h3>
                    <RadioGroup value={selectedType} onValueChange={setSelectedType}>
                      <div className="space-y-2">
                        {lensTypes.map((type) => (
                          <div key={type.name} className="flex items-center">
                            <RadioGroupItem value={type.name} id={`mobile-type-${type.name}`} />
                            <Label
                              htmlFor={`mobile-type-${type.name}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {type.name}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator className="my-4" />

                  {/* Lens Color */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Cor da Lente</h3>
                    <RadioGroup value={selectedColor} onValueChange={setSelectedColor}>
                      <div className="space-y-2">
                        {lensColors.map((color) => (
                          <div key={color.name} className="flex items-center">
                            <RadioGroupItem value={color.name} id={`mobile-color-${color.name}`} />
                            <Label
                              htmlFor={`mobile-color-${color.name}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {color.name}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator className="my-4" />

                  {/* Other Filters */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Outros Filtros</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-discount"
                          checked={showDiscount}
                          onCheckedChange={(checked) => setShowDiscount(!!checked)}
                        />
                        <Label htmlFor="mobile-discount" className="ml-2 text-sm font-normal cursor-pointer">
                          Em promoção
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-new"
                          checked={showNew}
                          onCheckedChange={(checked) => setShowNew(!!checked)}
                        />
                        <Label htmlFor="mobile-new" className="ml-2 text-sm font-normal cursor-pointer">
                          Lançamentos
                        </Label>
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setPriceRange([0, 250])
                      setSelectedBrand("Todas as marcas")
                      setSelectedType("Todos os tipos")
                      setSelectedColor("Todas as cores")
                      setShowDiscount(false)
                      setShowNew(false)
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Products */}
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0 flex items-center">
                  <Eye className="h-6 w-6 mr-2" />
                  Lentes de Contato
                </h1>

                {/* Sort */}
                <div className="w-full sm:w-auto">
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full sm:w-[200px]">
                      <SelectValue placeholder="Ordenar por" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">Relevância</SelectItem>
                      <SelectItem value="price-asc">Menor Preço</SelectItem>
                      <SelectItem value="price-desc">Maior Preço</SelectItem>
                      <SelectItem value="name-asc">Nome (A-Z)</SelectItem>
                      <SelectItem value="name-desc">Nome (Z-A)</SelectItem>
                      <SelectItem value="discount">Maior Desconto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Products Grid */}
              {sortedProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sortedProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">Nenhum produto encontrado com os filtros selecionados.</p>
                  <Button
                    variant="outline"
                    className="mt-4"
                    onClick={() => {
                      setPriceRange([0, 250])
                      setSelectedBrand("Todas as marcas")
                      setSelectedType("Todos os tipos")
                      setSelectedColor("Todas as cores")
                      setShowDiscount(false)
                      setShowNew(false)
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              )}

              {/* Pagination */}
              {sortedProducts.length > 0 && (
                <div className="flex justify-center mt-8">
                  <nav className="flex items-center space-x-2">
                    <Button variant="outline" size="icon" disabled>
                      <ChevronUp className="h-4 w-4 rotate-90" />
                    </Button>
                    <Button variant="outline" size="sm" className="bg-purple-600 text-white hover:bg-purple-700">
                      1
                    </Button>
                    <Button variant="outline" size="sm">
                      2
                    </Button>
                    <Button variant="outline" size="sm">
                      3
                    </Button>
                    <Button variant="outline" size="icon">
                      <ChevronDown className="h-4 w-4 rotate-90" />
                    </Button>
                  </nav>
                </div>
              )}
            </div>

            {/* Contact Lens Information */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Cuidados com Lentes de Contato</h2>
              <div className="text-gray-700 space-y-4">
                <p>
                  As lentes de contato são dispositivos médicos e requerem cuidados especiais para garantir a saúde dos
                  seus olhos. Sempre siga as orientações do seu oftalmologista quanto ao uso, limpeza e substituição das
                  suas lentes.
                </p>
                <p>
                  Lembre-se de lavar bem as mãos antes de manusear suas lentes, use sempre solução específica para
                  limpeza e armazenamento, e nunca durma com lentes que não são aprovadas para uso prolongado.
                </p>
                <div className="bg-purple-50 p-4 rounded-md mt-4">
                  <p className="text-purple-800 font-medium">
                    Dica: Mantenha sempre um par de óculos de reserva para os momentos em que não puder usar suas lentes
                    de contato.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

