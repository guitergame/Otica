"use client"

import { useState } from "react"
import Link from "next/link"
import {
  Filter,
  ChevronDown,
  ChevronUp,
  Sun,
  Square,
  Circle,
  Hexagon,
  Star,
  Bookmark,
  Palette,
  Users,
  Baby,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import ProductCard from "@/components/product-card"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for sunglasses
const sunglassesProducts = [
  {
    id: "sun-1",
    name: "Óculos de Sol Ray-Ban Aviator Classic",
    brand: "Ray-Ban",
    price: 599.9,
    originalPrice: 799.9,
    discount: 25,
    image:
      "https://images.unsplash.com/photo-1572635196237-14b3f281503f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#714B23", "#000000", "#0F4D92"],
    isNew: false,
  },
  {
    id: "sun-2",
    name: "Óculos de Sol Oakley Holbrook",
    brand: "Oakley",
    price: 499.9,
    image:
      "https://images.unsplash.com/photo-1577803645773-f96470509666?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#1A2B3C", "#8B0000"],
    isNew: true,
  },
  {
    id: "sun-3",
    name: "Óculos de Sol Prada Linea Rossa",
    brand: "Prada",
    price: 1299.9,
    originalPrice: 1599.9,
    discount: 19,
    image:
      "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#1A1A1A"],
    isNew: false,
  },
  {
    id: "sun-4",
    name: "Óculos de Sol Versace VE4361",
    brand: "Versace",
    price: 1099.9,
    originalPrice: 1399.9,
    discount: 21,
    image:
      "https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#FFD700"],
    isNew: false,
  },
  {
    id: "sun-5",
    name: "Óculos de Sol Gucci GG0896S",
    brand: "Gucci",
    price: 1899.9,
    image:
      "https://images.pexels.com/photos/2811088/pexels-photo-2811088.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#714B23", "#8B4513"],
    isNew: true,
  },
  {
    id: "sun-6",
    name: "Óculos de Sol Dior DIORETOILE1",
    brand: "Dior",
    price: 2199.9,
    originalPrice: 2499.9,
    discount: 12,
    image:
      "https://images.unsplash.com/photo-1625591338875-e2cca9de80a0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#4A4A4A"],
    isNew: false,
  },
  {
    id: "sun-7",
    name: "Óculos de Sol Carrera 1007/S",
    brand: "Carrera",
    price: 699.9,
    image:
      "https://images.pexels.com/photos/1054777/pexels-photo-1054777.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#0F4D92", "#8B0000"],
    isNew: false,
  },
  {
    id: "sun-8",
    name: "Óculos de Sol Michael Kors MK2024",
    brand: "Michael Kors",
    price: 899.9,
    originalPrice: 1099.9,
    discount: 18,
    image:
      "https://images.unsplash.com/photo-1614715838608-dd527c46231d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#8B4513"],
    isNew: false,
  },
  {
    id: "sun-9",
    name: "Óculos de Sol Burberry BE4216",
    brand: "Burberry",
    price: 1099.9,
    image:
      "https://images.pexels.com/photos/2589653/pexels-photo-2589653.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#8B4513", "#0F4D92"],
    isNew: true,
  },
  {
    id: "sun-10",
    name: "Óculos de Sol Armani Exchange AX4079S",
    brand: "Armani Exchange",
    price: 799.9,
    originalPrice: 999.9,
    discount: 20,
    image:
      "https://images.unsplash.com/photo-1619089662078-7fda3fdec7ac?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#1A1A1A", "#4A4A4A"],
    isNew: false,
  },
  {
    id: "sun-11",
    name: "Óculos de Sol Miu Miu MU 53SS",
    brand: "Miu Miu",
    price: 1599.9,
    image:
      "https://images.pexels.com/photos/5752277/pexels-photo-5752277.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#FFD700"],
    isNew: true,
  },
  {
    id: "sun-12",
    name: "Óculos de Sol Tom Ford FT0711",
    brand: "Tom Ford",
    price: 1799.9,
    originalPrice: 1999.9,
    discount: 10,
    image:
      "https://images.pexels.com/photos/2765872/pexels-photo-2765872.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#714B23", "#8B4513"],
    isNew: false,
  },
]

const brands = [
  "Todas as marcas",
  "Ray-Ban",
  "Oakley",
  "Prada",
  "Versace",
  "Gucci",
  "Dior",
  "Carrera",
  "Michael Kors",
  "Burberry",
  "Armani Exchange",
  "Miu Miu",
  "Tom Ford",
]

const frameShapes = [
  { name: "Todos os formatos", icon: Sun },
  { name: "Redondo", icon: Circle },
  { name: "Quadrado", icon: Square },
  { name: "Retangular", icon: Bookmark },
  { name: "Aviador", icon: Star },
  { name: "Gatinho", icon: Hexagon },
  { name: "Esportivo", icon: Star },
  { name: "Oval", icon: Circle },
]

const lensColors = [
  { name: "Todas as cores", icon: Palette },
  { name: "Preto", icon: Palette },
  { name: "Marrom", icon: Palette },
  { name: "Verde", icon: Palette },
  { name: "Azul", icon: Palette },
  { name: "Cinza", icon: Palette },
  { name: "Espelhado", icon: Palette },
  { name: "Degradê", icon: Palette },
]

const genders = [
  { name: "Todos", icon: Sun },
  { name: "Masculino", icon: Square },
  { name: "Feminino", icon: Circle },
  { name: "Unissex", icon: Users },
  { name: "Infantil", icon: Baby },
]

export default function SunglassesPage() {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2500])
  const [selectedBrand, setSelectedBrand] = useState("Todas as marcas")
  const [selectedShape, setSelectedShape] = useState("Todos os formatos")
  const [selectedLensColor, setSelectedLensColor] = useState("Todas as cores")
  const [selectedGender, setSelectedGender] = useState("Todos")
  const [showDiscount, setShowDiscount] = useState(false)
  const [showNew, setShowNew] = useState(false)
  const [sortBy, setSortBy] = useState("relevance")

  // Filter products based on selected filters
  const filteredProducts = sunglassesProducts.filter((product) => {
    // Filter by price range
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false
    }

    // Filter by brand
    if (selectedBrand !== "Todas as marcas" && product.brand !== selectedBrand) {
      return false
    }

    // Filter by discount
    if (showDiscount && !product.discount) {
      return false
    }

    // Filter by new
    if (showNew && !product.isNew) {
      return false
    }

    return true
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return a.price - b.price
      case "price-desc":
        return b.price - a.price
      case "name-asc":
        return a.name.localeCompare(b.name)
      case "name-desc":
        return b.name.localeCompare(a.name)
      case "discount":
        const discountA = a.discount || 0
        const discountB = b.discount || 0
        return discountB - discountA
      default:
        return 0
    }
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col space-y-4">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-purple-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-900 font-medium">Óculos de Sol</span>
        </nav>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="md:block w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-24">
              <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filtros
              </h2>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Palette className="h-4 w-4 mr-2" />
                  Preço
                </h3>
                <Slider
                  defaultValue={[0, 2500]}
                  max={2500}
                  step={50}
                  value={priceRange}
                  onValueChange={(value) => setPriceRange(value as [number, number])}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>R$ {priceRange[0].toLocaleString("pt-BR")}</span>
                  <span>R$ {priceRange[1].toLocaleString("pt-BR")}</span>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Brands */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Star className="h-4 w-4 mr-2" />
                  Marcas
                </h3>
                <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                  <div className="space-y-2">
                    {brands.map((brand) => (
                      <div key={brand} className="flex items-center">
                        <RadioGroupItem value={brand} id={`brand-${brand}`} />
                        <Label htmlFor={`brand-${brand}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {brand}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Frame Shape */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Square className="h-4 w-4 mr-2" />
                  Formato da Armação
                </h3>
                <RadioGroup value={selectedShape} onValueChange={setSelectedShape}>
                  <div className="space-y-2">
                    {frameShapes.map((shape) => (
                      <div key={shape.name} className="flex items-center">
                        <RadioGroupItem value={shape.name} id={`shape-${shape.name}`} />
                        <Label
                          htmlFor={`shape-${shape.name}`}
                          className="ml-2 text-sm font-normal cursor-pointer flex items-center"
                        >
                          <shape.icon className="h-4 w-4 mr-2" />
                          {shape.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Lens Color */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Palette className="h-4 w-4 mr-2" />
                  Cor da Lente
                </h3>
                <RadioGroup value={selectedLensColor} onValueChange={setSelectedLensColor}>
                  <div className="space-y-2">
                    {lensColors.map((color) => (
                      <div key={color.name} className="flex items-center">
                        <RadioGroupItem value={color.name} id={`color-${color.name}`} />
                        <Label
                          htmlFor={`color-${color.name}`}
                          className="ml-2 text-sm font-normal cursor-pointer flex items-center"
                        >
                          <color.icon className="h-4 w-4 mr-2" />
                          {color.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Gender */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                  <Users className="h-4 w-4 mr-2" />
                  Gênero
                </h3>
                <RadioGroup value={selectedGender} onValueChange={setSelectedGender}>
                  <div className="space-y-2">
                    {genders.map((gender) => (
                      <div key={gender.name} className="flex items-center">
                        <RadioGroupItem value={gender.name} id={`gender-${gender.name}`} />
                        <Label
                          htmlFor={`gender-${gender.name}`}
                          className="ml-2 text-sm font-normal cursor-pointer flex items-center"
                        >
                          <gender.icon className="h-4 w-4 mr-2" />
                          {gender.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Other Filters */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Outros Filtros</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox
                      id="discount"
                      checked={showDiscount}
                      onCheckedChange={(checked) => setShowDiscount(!!checked)}
                    />
                    <Label htmlFor="discount" className="ml-2 text-sm font-normal cursor-pointer">
                      Em promoção
                    </Label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="new" checked={showNew} onCheckedChange={(checked) => setShowNew(!!checked)} />
                    <Label htmlFor="new" className="ml-2 text-sm font-normal cursor-pointer">
                      Lançamentos
                    </Label>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setPriceRange([0, 2500])
                  setSelectedBrand("Todas as marcas")
                  setSelectedShape("Todos os formatos")
                  setSelectedLensColor("Todas as cores")
                  setSelectedGender("Todos")
                  setShowDiscount(false)
                  setShowNew(false)
                }}
              >
                Limpar Filtros
              </Button>
            </div>
          </div>

          {/* Mobile Filters */}
          <div className="md:hidden mb-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center justify-center">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px] overflow-auto">
                <div className="py-4">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">Filtros</h2>

                  {/* Price Range */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Preço</h3>
                    <Slider
                      defaultValue={[0, 2500]}
                      max={2500}
                      step={50}
                      value={priceRange}
                      onValueChange={(value) => setPriceRange(value as [number, number])}
                      className="mb-2"
                    />
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>R$ {priceRange[0].toLocaleString("pt-BR")}</span>
                      <span>R$ {priceRange[1].toLocaleString("pt-BR")}</span>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Brands */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Marcas</h3>
                    <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                      <div className="space-y-2">
                        {brands.map((brand) => (
                          <div key={brand} className="flex items-center">
                            <RadioGroupItem value={brand} id={`mobile-brand-${brand}`} />
                            <Label
                              htmlFor={`mobile-brand-${brand}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {brand}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator className="my-4" />

                  {/* Other Filters */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Outros Filtros</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-discount"
                          checked={showDiscount}
                          onCheckedChange={(checked) => setShowDiscount(!!checked)}
                        />
                        <Label htmlFor="mobile-discount" className="ml-2 text-sm font-normal cursor-pointer">
                          Em promoção
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-new"
                          checked={showNew}
                          onCheckedChange={(checked) => setShowNew(!!checked)}
                        />
                        <Label htmlFor="mobile-new" className="ml-2 text-sm font-normal cursor-pointer">
                          Lançamentos
                        </Label>
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setPriceRange([0, 2500])
                      setSelectedBrand("Todas as marcas")
                      setSelectedShape("Todos os formatos")
                      setSelectedLensColor("Todas as cores")
                      setSelectedGender("Todos")
                      setShowDiscount(false)
                      setShowNew(false)
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Products */}
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0 flex items-center">
                  <Sun className="h-6 w-6 mr-2" />
                  Óculos de Sol
                </h1>

                {/* Sort */}
                <div className="w-full sm:w-auto">
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full sm:w-[200px]">
                      <SelectValue placeholder="Ordenar por" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">Relevância</SelectItem>
                      <SelectItem value="price-asc">Menor Preço</SelectItem>
                      <SelectItem value="price-desc">Maior Preço</SelectItem>
                      <SelectItem value="name-asc">Nome (A-Z)</SelectItem>
                      <SelectItem value="name-desc">Nome (Z-A)</SelectItem>
                      <SelectItem value="discount">Maior Desconto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Products Grid */}
              {sortedProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sortedProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">Nenhum produto encontrado com os filtros selecionados.</p>
                  <Button
                    variant="outline"
                    className="mt-4"
                    onClick={() => {
                      setPriceRange([0, 2500])
                      setSelectedBrand("Todas as marcas")
                      setSelectedShape("Todos os formatos")
                      setSelectedLensColor("Todas as cores")
                      setSelectedGender("Todos")
                      setShowDiscount(false)
                      setShowNew(false)
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              )}

              {/* Pagination */}
              {sortedProducts.length > 0 && (
                <div className="flex justify-center mt-8">
                  <nav className="flex items-center space-x-2">
                    <Button variant="outline" size="icon" disabled>
                      <ChevronUp className="h-4 w-4 rotate-90" />
                    </Button>
                    <Button variant="outline" size="sm" className="bg-purple-600 text-white hover:bg-purple-700">
                      1
                    </Button>
                    <Button variant="outline" size="sm">
                      2
                    </Button>
                    <Button variant="outline" size="sm">
                      3
                    </Button>
                    <Button variant="outline" size="icon">
                      <ChevronDown className="h-4 w-4 rotate-90" />
                    </Button>
                  </nav>
                </div>
              )}
            </div>

            {/* UV Protection Information */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Proteção UV</h2>
              <div className="text-gray-700 space-y-4">
                <p>
                  Todos os nossos óculos de sol oferecem 100% de proteção contra raios UVA e UVB, essencial para a saúde
                  dos seus olhos. A exposição prolongada à radiação ultravioleta pode causar danos à córnea, catarata e
                  outras condições oculares.
                </p>
                <p>
                  Ao escolher seus óculos de sol, considere não apenas o estilo, mas também a qualidade das lentes e o
                  nível de proteção oferecido. Nossas lentes são testadas e certificadas para garantir a máxima
                  proteção.
                </p>
                <div className="bg-purple-50 p-4 rounded-md mt-4">
                  <p className="text-purple-800 font-medium">
                    Dica: Mesmo em dias nublados, os raios UV podem danificar seus olhos. Use óculos de sol de qualidade
                    durante todo o ano para proteção adequada.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

