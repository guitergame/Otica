"use client"

import { useState } from "react"
import Link from "next/link"
import { Filter, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import ProductCard from "@/components/product-card"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for eyeglasses
const eyeglassesProducts = [
  {
    id: "glasses-1",
    name: "Óculos de Grau Ray-Ban RX5154 Clubmaster",
    brand: "Ray-Ban",
    price: 699.9,
    originalPrice: 899.9,
    discount: 22,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#714B23", "#8B4513"],
    isNew: false,
  },
  {
    id: "glasses-2",
    name: "Óculos de Grau Oakley Crosslink",
    brand: "Oakley",
    price: 799.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#1A2B3C", "#808080"],
    isNew: true,
  },
  {
    id: "glasses-3",
    name: "Óculos de Grau Vogue VO5286",
    brand: "Vogue",
    price: 499.9,
    originalPrice: 599.9,
    discount: 16,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#8B4513", "#4B0082"],
    isNew: false,
  },
  {
    id: "glasses-4",
    name: "Óculos de Grau Tommy Hilfiger TH1689",
    brand: "Tommy Hilfiger",
    price: 599.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#0F4D92", "#8B0000"],
    isNew: true,
  },
  {
    id: "glasses-5",
    name: "Óculos de Grau Prada VPR29S",
    brand: "Prada",
    price: 1299.9,
    originalPrice: 1499.9,
    discount: 13,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#1A1A1A", "#4A4A4A"],
    isNew: false,
  },
  {
    id: "glasses-6",
    name: "Óculos de Grau Gucci GG0297OK",
    brand: "Gucci",
    price: 1599.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#714B23"],
    isNew: true,
  },
  {
    id: "glasses-7",
    name: "Óculos de Grau Dior DIORETOILE1",
    brand: "Dior",
    price: 1899.9,
    originalPrice: 2199.9,
    discount: 14,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#C0C0C0", "#4A4A4A"],
    isNew: false,
  },
  {
    id: "glasses-8",
    name: "Óculos de Grau Burberry BE2345",
    brand: "Burberry",
    price: 1099.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#8B4513", "#0F4D92"],
    isNew: false,
  },
  {
    id: "glasses-9",
    name: "Óculos de Grau Armani Exchange AX3048",
    brand: "Armani Exchange",
    price: 799.9,
    originalPrice: 999.9,
    discount: 20,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#1A1A1A", "#4A4A4A"],
    isNew: false,
  },
  {
    id: "glasses-10",
    name: "Óculos de Grau Michael Kors MK4067",
    brand: "Michael Kors",
    price: 899.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#C0C0C0", "#8B4513"],
    isNew: true,
  },
  {
    id: "glasses-11",
    name: "Óculos de Grau Carrera 8829/V",
    brand: "Carrera",
    price: 699.9,
    originalPrice: 799.9,
    discount: 12,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#0F4D92", "#8B0000"],
    isNew: false,
  },
  {
    id: "glasses-12",
    name: "Óculos de Grau Emporio Armani EA3167",
    brand: "Emporio Armani",
    price: 899.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#1A1A1A", "#4A4A4A"],
    isNew: false,
  },
]

const brands = [
  "Todas as marcas",
  "Ray-Ban",
  "Oakley",
  "Vogue",
  "Tommy Hilfiger",
  "Prada",
  "Gucci",
  "Dior",
  "Burberry",
  "Armani Exchange",
  "Michael Kors",
  "Carrera",
  "Emporio Armani",
]

const frameShapes = [
  "Todos os formatos",
  "Redondo",
  "Quadrado",
  "Retangular",
  "Aviador",
  "Gatinho",
  "Clubmaster",
  "Oval",
]

const frameMaterials = ["Todos os materiais", "Metal", "Acetato", "Plástico", "Titânio", "Fibra de carbono", "Madeira"]

const genders = ["Todos", "Masculino", "Feminino", "Unissex", "Infantil"]

export default function EyeglassesPage() {
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000])
  const [selectedBrand, setSelectedBrand] = useState("Todas as marcas")
  const [selectedShape, setSelectedShape] = useState("Todos os formatos")
  const [selectedMaterial, setSelectedMaterial] = useState("Todos os materiais")
  const [selectedGender, setSelectedGender] = useState("Todos")
  const [showDiscount, setShowDiscount] = useState(false)
  const [showNew, setShowNew] = useState(false)
  const [sortBy, setSortBy] = useState("relevance")

  // Filter products based on selected filters
  const filteredProducts = eyeglassesProducts.filter((product) => {
    // Filter by price range
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false
    }

    // Filter by brand
    if (selectedBrand !== "Todas as marcas" && product.brand !== selectedBrand) {
      return false
    }

    // Filter by discount
    if (showDiscount && !product.discount) {
      return false
    }

    // Filter by new
    if (showNew && !product.isNew) {
      return false
    }

    return true
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return a.price - b.price
      case "price-desc":
        return b.price - a.price
      case "name-asc":
        return a.name.localeCompare(b.name)
      case "name-desc":
        return b.name.localeCompare(a.name)
      case "discount":
        const discountA = a.discount || 0
        const discountB = b.discount || 0
        return discountB - discountA
      default:
        return 0
    }
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col space-y-4">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-purple-600">
            Home
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-900 font-medium">Óculos de Grau</span>
        </nav>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="hidden md:block w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Filtros</h2>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Preço</h3>
                <Slider
                  defaultValue={[0, 2000]}
                  max={2000}
                  step={50}
                  value={priceRange}
                  onValueChange={(value) => setPriceRange(value as [number, number])}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>R$ {priceRange[0]}</span>
                  <span>R$ {priceRange[1]}</span>
                </div>
              </div>

              <Separator className="my-4" />

              {/* Brands */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Marcas</h3>
                <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                  <div className="space-y-2">
                    {brands.map((brand) => (
                      <div key={brand} className="flex items-center">
                        <RadioGroupItem value={brand} id={`brand-${brand}`} />
                        <Label htmlFor={`brand-${brand}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {brand}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Frame Shape */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Formato da Armação</h3>
                <RadioGroup value={selectedShape} onValueChange={setSelectedShape}>
                  <div className="space-y-2">
                    {frameShapes.map((shape) => (
                      <div key={shape} className="flex items-center">
                        <RadioGroupItem value={shape} id={`shape-${shape}`} />
                        <Label htmlFor={`shape-${shape}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {shape}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Frame Material */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Material da Armação</h3>
                <RadioGroup value={selectedMaterial} onValueChange={setSelectedMaterial}>
                  <div className="space-y-2">
                    {frameMaterials.map((material) => (
                      <div key={material} className="flex items-center">
                        <RadioGroupItem value={material} id={`material-${material}`} />
                        <Label htmlFor={`material-${material}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {material}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Gender */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Gênero</h3>
                <RadioGroup value={selectedGender} onValueChange={setSelectedGender}>
                  <div className="space-y-2">
                    {genders.map((gender) => (
                      <div key={gender} className="flex items-center">
                        <RadioGroupItem value={gender} id={`gender-${gender}`} />
                        <Label htmlFor={`gender-${gender}`} className="ml-2 text-sm font-normal cursor-pointer">
                          {gender}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <Separator className="my-4" />

              {/* Other Filters */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Outros Filtros</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox
                      id="discount"
                      checked={showDiscount}
                      onCheckedChange={(checked) => setShowDiscount(!!checked)}
                    />
                    <Label htmlFor="discount" className="ml-2 text-sm font-normal cursor-pointer">
                      Em promoção
                    </Label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="new" checked={showNew} onCheckedChange={(checked) => setShowNew(!!checked)} />
                    <Label htmlFor="new" className="ml-2 text-sm font-normal cursor-pointer">
                      Lançamentos
                    </Label>
                  </div>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setPriceRange([0, 2000])
                  setSelectedBrand("Todas as marcas")
                  setSelectedShape("Todos os formatos")
                  setSelectedMaterial("Todos os materiais")
                  setSelectedGender("Todos")
                  setShowDiscount(false)
                  setShowNew(false)
                }}
              >
                Limpar Filtros
              </Button>
            </div>
          </div>

          {/* Mobile Filters */}
          <div className="md:hidden mb-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center justify-center">
                  <Filter className="h-4 w-4 mr-2" />
                  Filtros
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px] overflow-auto">
                <div className="py-4">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">Filtros</h2>

                  {/* Price Range */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Preço</h3>
                    <Slider
                      defaultValue={[0, 2000]}
                      max={2000}
                      step={50}
                      value={priceRange}
                      onValueChange={(value) => setPriceRange(value as [number, number])}
                      className="mb-2"
                    />
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>R$ {priceRange[0]}</span>
                      <span>R$ {priceRange[1]}</span>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  {/* Brands */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Marcas</h3>
                    <RadioGroup value={selectedBrand} onValueChange={setSelectedBrand}>
                      <div className="space-y-2">
                        {brands.map((brand) => (
                          <div key={brand} className="flex items-center">
                            <RadioGroupItem value={brand} id={`mobile-brand-${brand}`} />
                            <Label
                              htmlFor={`mobile-brand-${brand}`}
                              className="ml-2 text-sm font-normal cursor-pointer"
                            >
                              {brand}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator className="my-4" />

                  {/* Other Filters */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Outros Filtros</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-discount"
                          checked={showDiscount}
                          onCheckedChange={(checked) => setShowDiscount(!!checked)}
                        />
                        <Label htmlFor="mobile-discount" className="ml-2 text-sm font-normal cursor-pointer">
                          Em promoção
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-new"
                          checked={showNew}
                          onCheckedChange={(checked) => setShowNew(!!checked)}
                        />
                        <Label htmlFor="mobile-new" className="ml-2 text-sm font-normal cursor-pointer">
                          Lançamentos
                        </Label>
                      </div>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setPriceRange([0, 2000])
                      setSelectedBrand("Todas as marcas")
                      setSelectedShape("Todos os formatos")
                      setSelectedMaterial("Todos os materiais")
                      setSelectedGender("Todos")
                      setShowDiscount(false)
                      setShowNew(false)
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Products */}
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-4 sm:mb-0">Óculos de Grau</h1>

                {/* Sort */}
                <div className="w-full sm:w-auto">
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full sm:w-[200px]">
                      <SelectValue placeholder="Ordenar por" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">Relevância</SelectItem>
                      <SelectItem value="price-asc">Menor Preço</SelectItem>
                      <SelectItem value="price-desc">Maior Preço</SelectItem>
                      <SelectItem value="name-asc">Nome (A-Z)</SelectItem>
                      <SelectItem value="name-desc">Nome (Z-A)</SelectItem>
                      <SelectItem value="discount">Maior Desconto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Products Grid */}
              {sortedProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sortedProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">Nenhum produto encontrado com os filtros selecionados.</p>
                  <Button
                    variant="outline"
                    className="mt-4"
                    onClick={() => {
                      setPriceRange([0, 2000])
                      setSelectedBrand("Todas as marcas")
                      setSelectedShape("Todos os formatos")
                      setSelectedMaterial("Todos os materiais")
                      setSelectedGender("Todos")
                      setShowDiscount(false)
                      setShowNew(false)
                    }}
                  >
                    Limpar Filtros
                  </Button>
                </div>
              )}

              {/* Pagination */}
              {sortedProducts.length > 0 && (
                <div className="flex justify-center mt-8">
                  <nav className="flex items-center space-x-2">
                    <Button variant="outline" size="icon" disabled>
                      <ChevronUp className="h-4 w-4 rotate-90" />
                    </Button>
                    <Button variant="outline" size="sm" className="bg-purple-600 text-white hover:bg-purple-700">
                      1
                    </Button>
                    <Button variant="outline" size="sm">
                      2
                    </Button>
                    <Button variant="outline" size="sm">
                      3
                    </Button>
                    <Button variant="outline" size="icon">
                      <ChevronDown className="h-4 w-4 rotate-90" />
                    </Button>
                  </nav>
                </div>
              )}
            </div>

            {/* Prescription Information */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Informações sobre Receita Médica</h2>
              <div className="text-gray-700 space-y-4">
                <p>
                  Para a compra de óculos de grau, é necessário anexar uma receita médica válida durante o processo de
                  checkout. A receita deve conter:
                </p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>Nome completo do paciente</li>
                  <li>Data da consulta (não superior a 1 ano)</li>
                  <li>Grau para cada olho (dioptria)</li>
                  <li>Assinatura e carimbo do médico oftalmologista</li>
                </ul>
                <p>
                  Você poderá enviar a receita em formato de imagem (JPG, PNG) ou PDF. Caso tenha dúvidas, entre em
                  contato com nossa equipe de atendimento.
                </p>
                <div className="bg-purple-50 p-4 rounded-md mt-4">
                  <p className="text-purple-800 font-medium">
                    Lembre-se: A receita médica é essencial para garantir que seus óculos sejam produzidos com as
                    especificações corretas para sua visão.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

