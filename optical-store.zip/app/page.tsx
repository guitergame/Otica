import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Glasses, Sun, Eye, Tag, ArrowRight, Star, TrendingUp, Gift, Truck, ShieldCheck, Clock } from "lucide-react"
import ProductCard from "@/components/product-card"

// Mock data for featured products
const featuredProducts = [
  {
    id: "1",
    name: "Óculos de Grau Ray-Ban RB7046",
    brand: "Ray-Ban",
    price: 699.9,
    image:
      "https://images.unsplash.com/photo-1574258495973-f010dfbb5371?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-grau",
    colors: ["#000000", "#714B23", "#0F4D92"],
  },
  {
    id: "2",
    name: "Óculos de Sol Oakley Holbrook",
    brand: "Oakley",
    price: 499.9,
    originalPrice: 599.9,
    discount: 17,
    image:
      "https://images.unsplash.com/photo-1577803645773-f96470509666?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#1A2B3C", "#8B0000"],
    isNew: true,
  },
  {
    id: "3",
    name: "Lentes de Contato Coloridas Solotica",
    brand: "Solotica",
    price: 149.9,
    image:
      "https://images.pexels.com/photos/5752287/pexels-photo-5752287.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#8B4513", "#228B22"],
  },
  {
    id: "4",
    name: "Óculos de Grau Prada VPS04L",
    brand: "Prada",
    price: 1299.9,
    originalPrice: 1599.9,
    discount: 19,
    image:
      "https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-grau",
    colors: ["#000000", "#1A1A1A"],
  },
]

// Mock data for new arrivals
const newArrivals = [
  {
    id: "5",
    name: "Óculos de Sol Versace VE4361",
    brand: "Versace",
    price: 1099.9,
    image:
      "https://images.pexels.com/photos/2811088/pexels-photo-2811088.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#FFD700"],
    isNew: true,
  },
  {
    id: "6",
    name: "Lentes de Contato Acuvue Oasys",
    brand: "Acuvue",
    price: 179.9,
    image:
      "https://images.pexels.com/photos/7760779/pexels-photo-7760779.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    isNew: true,
  },
  {
    id: "7",
    name: "Óculos de Grau Gucci GG0026O",
    brand: "Gucci",
    price: 1599.9,
    image:
      "https://images.pexels.com/photos/5698853/pexels-photo-5698853.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-grau",
    colors: ["#000000", "#714B23", "#8B4513"],
    isNew: true,
  },
  {
    id: "8",
    name: "Óculos de Sol Dior DIORETOILE1",
    brand: "Dior",
    price: 2199.9,
    image:
      "https://images.unsplash.com/photo-1625591338875-e2cca9de80a0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#4A4A4A"],
    isNew: true,
  },
]

// Mock data for best sellers
const bestSellers = [
  {
    id: "9",
    name: "Óculos de Sol Ray-Ban Aviator Classic",
    brand: "Ray-Ban",
    price: 599.9,
    originalPrice: 799.9,
    discount: 25,
    image:
      "https://images.unsplash.com/photo-1572635196237-14b3f281503f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#714B23", "#000000", "#0F4D92"],
  },
  {
    id: "10",
    name: "Óculos de Grau Oakley Crosslink",
    brand: "Oakley",
    price: 799.9,
    image: "https://images.freepik.com/free-photo/eyeglasses-table_23-2147877037.jpg",
    category: "oculos-de-grau",
    colors: ["#000000", "#0F4D92", "#8B0000"],
  },
  {
    id: "11",
    name: "Lentes de Contato Coloridas Hidrocor",
    brand: "Hidrocor",
    price: 129.9,
    originalPrice: 149.9,
    discount: 13,
    image:
      "https://images.pexels.com/photos/8179216/pexels-photo-8179216.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
    colors: ["#0F4D92", "#228B22", "#8B4513"],
  },
  {
    id: "12",
    name: "Óculos de Sol Carrera 1007/S",
    brand: "Carrera",
    price: 699.9,
    image:
      "https://images.pexels.com/photos/1054777/pexels-photo-1054777.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "oculos-de-sol",
    colors: ["#000000", "#0F4D92", "#8B0000"],
  },
]

// Mock data for promotions
const promotions = [
  {
    id: "13",
    name: "Óculos de Sol Michael Kors MK2024",
    brand: "Michael Kors",
    price: 899.9,
    originalPrice: 1099.9,
    discount: 18,
    image:
      "https://images.unsplash.com/photo-1614715838608-dd527c46231d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#8B4513"],
  },
  {
    id: "14",
    name: "Óculos de Grau Vogue VO5356",
    brand: "Vogue",
    price: 499.9,
    originalPrice: 599.9,
    discount: 17,
    image: "https://images.freepik.com/free-photo/eyeglasses-with-black-frame-transparent-glasses_23-2148516555.jpg",
    category: "oculos-de-grau",
    colors: ["#000000", "#8B4513", "#4A4A4A"],
  },
  {
    id: "15",
    name: "Lentes de Contato Acuvue 2",
    brand: "Acuvue",
    price: 129.9,
    originalPrice: 159.9,
    discount: 19,
    image:
      "https://images.pexels.com/photos/8460290/pexels-photo-8460290.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    category: "lentes-de-contato",
  },
  {
    id: "16",
    name: "Óculos de Sol Armani Exchange AX4079S",
    brand: "Armani Exchange",
    price: 799.9,
    originalPrice: 999.9,
    discount: 20,
    image:
      "https://images.unsplash.com/photo-1619089662078-7fda3fdec7ac?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1160&q=80",
    category: "oculos-de-sol",
    colors: ["#000000", "#1A1A1A", "#4A4A4A"],
  },
]

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative h-[500px] md:h-[600px] overflow-hidden">
        <Image
          src="https://images.pexels.com/photos/1499480/pexels-photo-1499480.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          alt="Ótica Premium - Óculos de qualidade"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30 flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-xl">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Veja o mundo com mais estilo</h1>
              <p className="text-lg md:text-xl text-white/90 mb-8">
                Descubra nossa coleção exclusiva de óculos e lentes de contato das melhores marcas do mundo.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                  Explorar Coleção
                </Button>
                <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/20">
                  Agendar Consulta
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Nossas Categorias</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Eyeglasses Category */}
            <Card className="overflow-hidden group">
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src="https://images.pexels.com/photos/5698853/pexels-photo-5698853.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Óculos de Grau"
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2 flex items-center">
                      <Glasses className="h-5 w-5 mr-2" />
                      Óculos de Grau
                    </h3>
                    <Link href="/categoria/oculos-de-grau">
                      <Button variant="outline" className="bg-white text-gray-900 hover:bg-gray-100">
                        <Glasses className="h-4 w-4 mr-2" />
                        Ver Coleção
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </Card>

            {/* Sunglasses Category */}
            <Card className="overflow-hidden group">
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src="https://images.pexels.com/photos/2811088/pexels-photo-2811088.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Óculos de Sol"
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2 flex items-center">
                      <Sun className="h-5 w-5 mr-2" />
                      Óculos de Sol
                    </h3>
                    <Link href="/categoria/oculos-de-sol">
                      <Button variant="outline" className="bg-white text-gray-900 hover:bg-gray-100">
                        <Sun className="h-4 w-4 mr-2" />
                        Ver Coleção
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </Card>

            {/* Contact Lenses Category */}
            <Card className="overflow-hidden group">
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src="https://images.pexels.com/photos/5752287/pexels-photo-5752287.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Lentes de Contato"
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2 flex items-center">
                      <Eye className="h-5 w-5 mr-2" />
                      Lentes de Contato
                    </h3>
                    <Link href="/categoria/lentes-de-contato">
                      <Button variant="outline" className="bg-white text-gray-900 hover:bg-gray-100">
                        <Eye className="h-4 w-4 mr-2" />
                        Ver Coleção
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </Card>

            {/* Outlet Category */}
            <Card className="overflow-hidden group">
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src="https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                  alt="Outlet"
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2 flex items-center">
                      <Tag className="h-5 w-5 mr-2" />
                      Outlet
                    </h3>
                    <Link href="/categoria/outlet">
                      <Button variant="outline" className="bg-white text-gray-900 hover:bg-gray-100">
                        <Tag className="h-4 w-4 mr-2" />
                        Ver Ofertas
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12">Produtos em Destaque</h2>

          <Tabs defaultValue="featured">
            <TabsList className="mb-8">
              <TabsTrigger value="featured">Destaques</TabsTrigger>
              <TabsTrigger value="new">Lançamentos</TabsTrigger>
              <TabsTrigger value="bestsellers">Mais Vendidos</TabsTrigger>
              <TabsTrigger value="promotions">Promoções</TabsTrigger>
            </TabsList>

            <TabsContent value="featured">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="new">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {newArrivals.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="bestsellers">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {bestSellers.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="promotions">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {promotions.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </TabsContent>
          </Tabs>

          <div className="text-center mt-12">
            <Link href="/produtos">
              <Button className="bg-purple-600 hover:bg-purple-700">
                Ver Todos os Produtos <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Brands Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Marcas Parceiras</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {/* Brand Logos */}
            <div className="flex items-center justify-center p-4 bg-white rounded-lg shadow-sm">
              <Image src="/placeholder.svg?height=60&width=120" alt="Ray-Ban" width={120} height={60} />
            </div>
            <div className="flex items-center justify-center p-4 bg-white rounded-lg shadow-sm">
              <Image src="/placeholder.svg?height=60&width=120" alt="Oakley" width={120} height={60} />
            </div>
            <div className="flex items-center justify-center p-4 bg-white rounded-lg shadow-sm">
              <Image src="/placeholder.svg?height=60&width=120" alt="Prada" width={120} height={60} />
            </div>
            <div className="flex items-center justify-center p-4 bg-white rounded-lg shadow-sm">
              <Image src="/placeholder.svg?height=60&width=120" alt="Gucci" width={120} height={60} />
            </div>
            <div className="flex items-center justify-center p-4 bg-white rounded-lg shadow-sm">
              <Image src="/placeholder.svg?height=60&width=120" alt="Versace" width={120} height={60} />
            </div>
            <div className="flex items-center justify-center p-4 bg-white rounded-lg shadow-sm">
              <Image src="/placeholder.svg?height=60&width=120" alt="Dior" width={120} height={60} />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Por que escolher a Ótica Premium?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <Star className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Produtos Originais</h3>
                  <p className="text-gray-600">
                    Garantimos a autenticidade de todos os nossos produtos, com certificado de originalidade.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <TrendingUp className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Últimas Tendências</h3>
                  <p className="text-gray-600">
                    Atualizamos constantemente nosso catálogo com as últimas tendências do mercado óptico.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <Gift className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Atendimento Personalizado</h3>
                  <p className="text-gray-600">
                    Oferecemos consultoria especializada para ajudar você a encontrar o produto ideal para suas
                    necessidades.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <ShieldCheck className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-bold mb-2">Garantia Estendida</h3>
                  <p className="text-gray-600">
                    Todos os nossos produtos possuem garantia estendida, proporcionando mais segurança na sua compra.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Shipping Info Section */}
      <section className="py-8 bg-purple-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center justify-center md:justify-start">
              <Truck className="h-6 w-6 mr-2" />
              <span>Frete grátis para compras acima de R$ 300</span>
            </div>
            <div className="flex items-center justify-center">
              <Clock className="h-6 w-6 mr-2" />
              <span>Entrega expressa em até 48h</span>
            </div>
            <div className="flex items-center justify-center md:justify-end">
              <ShieldCheck className="h-6 w-6 mr-2" />
              <span>Pagamento 100% seguro</span>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">O que nossos clientes dizem</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <div className="flex items-center mb-4">
                    <div className="mr-4">
                      <Image
                        src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80"
                        alt="Cliente"
                        width={48}
                        height={48}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="font-bold">Ana Silva</h3>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 italic">
                    "Comprei meus óculos de grau e fiquei impressionada com a qualidade e o atendimento. Recomendo a
                    todos!"
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <div className="flex items-center mb-4">
                    <div className="mr-4">
                      <Image
                        src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80"
                        alt="Cliente"
                        width={48}
                        height={48}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="font-bold">Carlos Oliveira</h3>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 italic">
                    "As lentes de contato chegaram rapidamente e são exatamente como descritas. Ótima experiência de
                    compra!"
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col">
                  <div className="flex items-center mb-4">
                    <div className="mr-4">
                      <Image
                        src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=256&q=80"
                        alt="Cliente"
                        width={48}
                        height={48}
                        className="rounded-full"
                      />
                    </div>
                    <div>
                      <h3 className="font-bold">Mariana Santos</h3>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 italic">
                    "Comprei óculos de sol para toda a família e todos adoraram. Preço justo e produtos de qualidade!"
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Fique por dentro das novidades</h2>
            <p className="text-gray-600 mb-8">
              Assine nossa newsletter e receba ofertas exclusivas, lançamentos e dicas de cuidados com seus óculos.
            </p>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                placeholder="Seu melhor e-mail"
                className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-600"
              />
              <Button className="bg-purple-600 hover:bg-purple-700">Assinar Newsletter</Button>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}

