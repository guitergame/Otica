"use client"

import { useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts"
import { Users, ShoppingBag, DollarSign, TrendingUp } from "lucide-react"

// Mock data for charts
const salesData = [
  { name: "Jan", value: 12000 },
  { name: "Fev", value: 15000 },
  { name: "Mar", value: 18000 },
  { name: "Abr", value: 16000 },
  { name: "Mai", value: 21000 },
  { name: "Jun", value: 19000 },
  { name: "Jul", value: 22000 },
  { name: "Ago", value: 25000 },
  { name: "Set", value: 23000 },
  { name: "Out", value: 27000 },
  { name: "Nov", value: 32000 },
  { name: "Dez", value: 38000 },
]

const categoryData = [
  { name: "Óculos de Sol", value: 45 },
  { name: "Óculos de Grau", value: 35 },
  { name: "Lentes de Contato", value: 15 },
  { name: "Acessórios", value: 5 },
]

const COLORS = ["#8884d8", "#82ca9d", "#ffc658", "#ff8042"]

const orderStatusData = [
  { name: "Pendente", value: 15 },
  { name: "Em processamento", value: 25 },
  { name: "Enviado", value: 35 },
  { name: "Entregue", value: 120 },
  { name: "Cancelado", value: 5 },
]

export default function AdminDashboard() {
  useEffect(() => {
    // Set admin authenticated for demo purposes
    localStorage.setItem("adminAuthenticated", "true")
  }, [])

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <div className="text-sm text-gray-500">
          Última atualização: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Vendas Totais</p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">R$ 248.000,00</h3>
                <p className="text-xs text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +12% em relação ao mês anterior
                </p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <DollarSign className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Pedidos</p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">1.248</h3>
                <p className="text-xs text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +8% em relação ao mês anterior
                </p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <ShoppingBag className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Clientes</p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">854</h3>
                <p className="text-xs text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +5% em relação ao mês anterior
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <Users className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">Ticket Médio</p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">R$ 198,72</h3>
                <p className="text-xs text-green-600 mt-1 flex items-center">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +3% em relação ao mês anterior
                </p>
              </div>
              <div className="bg-amber-100 p-3 rounded-full">
                <DollarSign className="h-6 w-6 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Combined Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Sales Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Vendas Mensais (2023)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={salesData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`R$ ${value.toLocaleString()}`, "Vendas"]} />
                  <Bar dataKey="value" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Orders Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Status dos Pedidos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={orderStatusData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" stroke="#8884d8" activeDot={{ r: 8 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Categories Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Vendas por Categoria (%)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card>
        <CardHeader>
          <CardTitle>Pedidos Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Pedido</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Cliente</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Data</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                  <th className="py-3 px-4 text-left font-medium text-gray-700">Total</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-gray-900">#ORD-001234</td>
                  <td className="py-3 px-4 text-gray-700">João Silva</td>
                  <td className="py-3 px-4 text-gray-700">05/05/2023</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Entregue
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-900">R$ 599,90</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-gray-900">#ORD-001235</td>
                  <td className="py-3 px-4 text-gray-700">Maria Oliveira</td>
                  <td className="py-3 px-4 text-gray-700">05/05/2023</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Em trânsito
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-900">R$ 1.299,80</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-gray-900">#ORD-001236</td>
                  <td className="py-3 px-4 text-gray-700">Pedro Santos</td>
                  <td className="py-3 px-4 text-gray-700">05/05/2023</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      Processando
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-900">R$ 349,90</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-gray-900">#ORD-001237</td>
                  <td className="py-3 px-4 text-gray-700">Ana Costa</td>
                  <td className="py-3 px-4 text-gray-700">04/05/2023</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Entregue
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-900">R$ 799,90</td>
                </tr>
                <tr className="border-b border-gray-200">
                  <td className="py-3 px-4 text-gray-900">#ORD-001238</td>
                  <td className="py-3 px-4 text-gray-700">Carlos Ferreira</td>
                  <td className="py-3 px-4 text-gray-700">04/05/2023</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      Cancelado
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-900">R$ 499,90</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

