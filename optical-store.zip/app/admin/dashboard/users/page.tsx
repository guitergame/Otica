"use client"

import type React from "react"

import { useState } from "react"
import { Search, ChevronRight, ChevronLeft, ArrowUpDown, Eye, Edit, Trash2, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useToast } from "@/components/ui/use-toast"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"

// Mock admin users data
const mockUsers = [
  {
    id: "1",
    name: "Admin Principal",
    email: "admin@oticapremium.com",
    role: "admin",
    status: "active",
    lastLogin: "2023-05-10T14:32:15",
    createdAt: "2023-01-01T10:00:00",
    permissions: ["all"],
    address: {
      street: "Av. Paulista",
      number: "1000",
      complement: "Sala 123",
      neighborhood: "Bela Vista",
      city: "São Paulo",
      state: "SP",
      zipCode: "01310-100",
    },
    phone: "(11) 98765-4321",
  },
  {
    id: "2",
    name: "Gerente de Vendas",
    email: "gerente@oticapremium.com",
    role: "manager",
    status: "active",
    lastLogin: "2023-05-09T09:15:30",
    createdAt: "2023-01-15T11:30:00",
    permissions: ["products", "orders", "customers", "reports"],
    address: {
      street: "Rua Augusta",
      number: "500",
      complement: "",
      neighborhood: "Consolação",
      city: "São Paulo",
      state: "SP",
      zipCode: "01305-000",
    },
    phone: "(11) 97654-3210",
  },
  {
    id: "3",
    name: "Atendente 1",
    email: "atendente1@oticapremium.com",
    role: "staff",
    status: "active",
    lastLogin: "2023-05-08T16:45:22",
    createdAt: "2023-02-01T09:00:00",
    permissions: ["orders", "customers"],
    address: {
      street: "Av. Rebouças",
      number: "300",
      complement: "Apto 45",
      neighborhood: "Pinheiros",
      city: "São Paulo",
      state: "SP",
      zipCode: "05401-000",
    },
    phone: "(11) 96543-2109",
  },
  {
    id: "4",
    name: "Atendente 2",
    email: "atendente2@oticapremium.com",
    role: "staff",
    status: "inactive",
    lastLogin: "2023-04-15T10:12:05",
    createdAt: "2023-02-15T14:00:00",
    permissions: ["orders", "customers"],
    address: {
      street: "Rua Oscar Freire",
      number: "200",
      complement: "",
      neighborhood: "Jardins",
      city: "São Paulo",
      state: "SP",
      zipCode: "01426-000",
    },
    phone: "(11) 95432-1098",
  },
  {
    id: "5",
    name: "Estoquista",
    email: "estoque@oticapremium.com",
    role: "staff",
    status: "active",
    lastLogin: "2023-05-07T11:30:18",
    createdAt: "2023-03-01T08:30:00",
    permissions: ["products"],
    address: {
      street: "Av. Brigadeiro Faria Lima",
      number: "1500",
      complement: "Bloco B",
      neighborhood: "Jardim Paulistano",
      city: "São Paulo",
      state: "SP",
      zipCode: "01452-001",
    },
    phone: "(11) 94321-0987",
  },
]

export default function UsersPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [users, setUsers] = useState(mockUsers)
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "staff",
    status: "active",
  })

  // Filter users based on search
  const filteredUsers = users.filter((user) => {
    return (
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })

  const handleViewUser = (user: any) => {
    setSelectedUser(user)
    setIsViewDialogOpen(true)
  }

  const handleEditUser = (user: any) => {
    setSelectedUser({
      ...user,
      password: "",
      confirmPassword: "",
    })
    setIsEditDialogOpen(true)
  }

  const handleDeleteUser = (user: any) => {
    setSelectedUser(user)
    setIsDeleteDialogOpen(true)
  }

  const confirmDeleteUser = () => {
    if (selectedUser) {
      setUsers(users.filter((user) => user.id !== selectedUser.id))
      toast({
        title: "Usuário excluído",
        description: `O usuário ${selectedUser.name} foi excluído com sucesso.`,
      })
      setIsDeleteDialogOpen(false)
    }
  }

  const handleUpdateUser = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (selectedUser.password && selectedUser.password !== selectedUser.confirmPassword) {
      toast({
        title: "Senhas não conferem",
        description: "As senhas digitadas não são iguais.",
        variant: "destructive",
      })
      return
    }

    setUsers(users.map((user) => (user.id === selectedUser.id ? { ...selectedUser } : user)))
    toast({
      title: "Usuário atualizado",
      description: `O usuário ${selectedUser.name} foi atualizado com sucesso.`,
    })
    setIsEditDialogOpen(false)
  }

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!newUser.name || !newUser.email || !newUser.password || !  => {\
    e.preventDefault()
    
    if (!newUser.name || !newUser.email || !newUser.password || !newUser.confirmPassword) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    if (newUser.password !== newUser.confirmPassword) {
      toast({
        title: "Senhas não conferem",
        description: "As senhas digitadas não são iguais.",
        variant: "destructive",
      })
      return
    }

    const newId = (Math.max(...users.map((user) => Number.parseInt(user.id))) + 1).toString()
    
    setUsers([
      ...users,
      {
        id: newId,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        status: newUser.status,
        lastLogin: null,
        createdAt: new Date().toISOString(),
        permissions: newUser.role === "admin" ? ["all"] : newUser.role === "manager" ? ["products", "orders", "customers", "reports"] : ["orders", "customers"],
        address: {
          street: "",
          number: "",
          complement: "",
          neighborhood: "",
          city: "",
          state: "",
          zipCode: "",
        },
        phone: "",
      },
    ])
    
    toast({
      title: "Usuário adicionado",
      description: `O usuário ${newUser.name} foi adicionado com sucesso.`,
    })
    
    setNewUser({
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      role: "staff",
      status: "active",
    })
    
    setIsAddDialogOpen(false)
  }

  const getRoleBadge = (role: string) => {
    switch (role) {
      case "admin":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Administrador</Badge>
      case "manager":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Gerente</Badge>
      case "staff":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Atendente</Badge>
      default:
        return <Badge variant="outline">{role}</Badge>
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Ativo</Badge>
      case "inactive":
        return <Badge variant="outline" className="text-gray-500 border-gray-300 hover:bg-transparent">Inativo</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const formatDateTime = (timestamp: string) => {
    if (!timestamp) return "Nunca"
    const date = new Date(timestamp)
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Usuários do Sistema</h1>
        <Button
          onClick={() => setIsAddDialogOpen(true)}
          className="mt-4 md:mt-0 bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Usuário
        </Button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <Input
            placeholder="Buscar por nome, email ou função..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Nome
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Email
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Função</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Último Login
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-right font-medium text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-900">{user.name}</td>
                    <td className="py-3 px-4 text-gray-700">{user.email}</td>
                    <td className="py-3 px-4">{getRoleBadge(user.role)}</td>
                    <td className="py-3 px-4">{getStatusBadge(user.status)}</td>
                    <td className="py-3 px-4 text-gray-700">{formatDateTime(user.lastLogin)}</td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => handleViewUser(user)}>
                          <Eye className="h-4 w-4" />
                          <span className="sr-only">Ver</span>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleEditUser(user)}>
                          <Edit className="h-4 w-4" />
                          <span className="sr-only">Editar</span>
                        </Button>
                        {user.id !== "1" && (
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteUser(user)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                            <span className="sr-only">Excluir</span>
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-gray-500">
                    Nenhum usuário encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200">
          <div className="text-sm text-gray-500">
            Mostrando <span className="font-medium">{filteredUsers.length}</span> de{" "}
            <span className="font-medium">{users.length}</span> usuários
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4 mr-1" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" disabled>
              Próximo
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>

      {/* View User Dialog */}
      {selectedUser && (
        <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Detalhes do Usuário</DialogTitle>
              <DialogDescription>Informações detalhadas sobre o usuário.</DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="info" className="mt-4">
              <TabsList className="grid grid-cols-3 mb-6">
                <TabsTrigger value="info">Informações Pessoais</TabsTrigger>
                <TabsTrigger value="address">Endereço</TabsTrigger>
                <TabsTrigger value="permissions">Permissões</TabsTrigger>
              </TabsList>

              <TabsContent value="info">
                <Card>
                  <CardHeader>
                    <CardTitle>Informações Pessoais</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm text-gray-500">Nome</Label>
                        <p className="font-medium text-gray-900">{selectedUser.name}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Email</Label>
                        <p className="font-medium text-gray-900">{selectedUser.email}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Telefone</Label>
                        <p className="font-medium text-gray-900">{selectedUser.phone || "Não informado"}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Função</Label>
                        <div className="mt-1">{getRoleBadge(selectedUser.role)}</div>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Status</Label>
                        <div className="mt-1">{getStatusBadge(selectedUser.status)}</div>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Data de Criação</Label>
                        <p className="font-medium text-gray-900">{formatDateTime(selectedUser.createdAt)}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Último Login</Label>
                        <p className="font-medium text-gray-900">{formatDateTime(selectedUser.lastLogin)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="address">
                <Card>
                  <CardHeader>
                    <CardTitle>Endereço</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedUser.address ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label className="text-sm text-gray-500">Rua</Label>
                          <p className="font-medium text-gray-900">{selectedUser.address.street || "Não informado"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Número</Label>
                          <p className="font-medium text-gray-900">{selectedUser.address.number || "Não informado"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Complemento</Label>
                          <p className="font-medium text-gray-900">{selectedUser.address.complement || "Não informado"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Bairro</Label>
                          <p className="font-medium text-gray-900">{selectedUser.address.neighborhood || "Não informado"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Cidade</Label>
                          <p className="font-medium text-gray-900">{selectedUser.address.city || "Não informado"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Estado</Label>
                          <p className="font-medium text-gray-900">{selectedUser.address.state || "Não informado"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">CEP</Label>
                          <p className="font-medium text-gray-900">{selectedUser.address.zipCode || "Não informado"}</p>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-500">Nenhum endereço cadastrado.</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="permissions">
                <Card>
                  <CardHeader>
                    <CardTitle>Permissões</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedUser.permissions && selectedUser.permissions.includes("all") ? (
                      <p className="text-gray-900">Este usuário possui acesso total ao sistema.</p>
                    ) : (
                      <div className="space-y-2">
                        <p className="text-gray-900 mb-2">Este usuário possui acesso às seguintes áreas:</p>
                        <ul className="list-disc pl-5 space-y-1">
                          {selectedUser.permissions?.includes("products") && (
                            <li className="text-gray-700">Produtos</li>
                          )}
                          {selectedUser.permissions?.includes("orders") && (
                            <li className="text-gray-700">Pedidos</li>
                          )}
                          {selectedUser.permissions?.includes("customers") && (
                            <li className="text-gray-700">Clientes</li>
                          )}
                          {selectedUser.permissions?.includes("reports") && (
                            <li className="text-gray-700">Relatórios</li>
                          )}
                          {selectedUser.permissions?.includes("finance") && (
                            <li className="text-gray-700">Financeiro</li>
                          )}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}

      {/* Other dialogs would go here (Edit, Delete, Add) */}
    </div>
  )
}

