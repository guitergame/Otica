"use client"

import { useState } from "react"
import { Search, Filter, ChevronRight, ChevronLeft, ArrowUpDown, Eye, Mail, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Mock customer data
const mockCustomers = [
  {
    id: "1",
    name: "João Silva",
    email: "joao.silva@example.com",
    phone: "(11) 98765-4321",
    status: "active",
    orders: 5,
    totalSpent: 1299.7,
    lastOrder: "2023-05-10",
    createdAt: "2023-01-15",
  },
  {
    id: "2",
    name: "Maria Oliveira",
    email: "maria.oliveira@example.com",
    phone: "(21) 98765-4321",
    status: "active",
    orders: 3,
    totalSpent: 899.8,
    lastOrder: "2023-05-05",
    createdAt: "2023-02-20",
  },
  {
    id: "3",
    name: "Pedro Santos",
    email: "pedro.santos@example.com",
    phone: "(31) 98765-4321",
    status: "inactive",
    orders: 1,
    totalSpent: 349.9,
    lastOrder: "2023-03-15",
    createdAt: "2023-03-10",
  },
  {
    id: "4",
    name: "Ana Costa",
    email: "ana.costa@example.com",
    phone: "(41) 98765-4321",
    status: "active",
    orders: 2,
    totalSpent: 799.9,
    lastOrder: "2023-04-20",
    createdAt: "2023-04-05",
  },
  {
    id: "5",
    name: "Carlos Ferreira",
    email: "carlos.ferreira@example.com",
    phone: "(51) 98765-4321",
    status: "active",
    orders: 4,
    totalSpent: 1499.6,
    lastOrder: "2023-05-01",
    createdAt: "2023-03-25",
  },
  {
    id: "6",
    name: "Fernanda Lima",
    email: "fernanda.lima@example.com",
    phone: "(61) 98765-4321",
    status: "inactive",
    orders: 0,
    totalSpent: 0,
    lastOrder: null,
    createdAt: "2023-05-01",
  },
]

export default function CustomersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showActive, setShowActive] = useState(true)
  const [showInactive, setShowInactive] = useState(true)
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null)
  const [isCustomerDialogOpen, setIsCustomerDialogOpen] = useState(false)

  // Filter customers based on search and status
  const filteredCustomers = mockCustomers.filter((customer) => {
    const matchesSearch =
      customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.phone.includes(searchQuery)
    const matchesStatus =
      (showActive && customer.status === "active") || (showInactive && customer.status === "inactive")

    return matchesSearch && matchesStatus
  })

  const handleViewCustomer = (customer: any) => {
    setSelectedCustomer(customer)
    setIsCustomerDialogOpen(true)
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Clientes</h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar por nome, email ou telefone..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="w-full md:w-auto justify-between">
                  <div className="flex items-center">
                    <Filter className="mr-2 h-4 w-4" />
                    Status
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="p-2">
                  <div className="flex items-center space-x-2 mb-2">
                    <Checkbox
                      id="active"
                      checked={showActive}
                      onCheckedChange={(checked) => setShowActive(checked as boolean)}
                    />
                    <label
                      htmlFor="active"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Ativos
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="inactive"
                      checked={showInactive}
                      onCheckedChange={(checked) => setShowInactive(checked as boolean)}
                    />
                    <label
                      htmlFor="inactive"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Inativos
                    </label>
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("")
                setShowActive(true)
                setShowInactive(true)
              }}
            >
              Limpar Filtros
            </Button>
          </div>
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Cliente
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Contato</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Pedidos
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Total Gasto
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Último Pedido
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                <th className="py-3 px-4 text-right font-medium text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.length > 0 ? (
                filteredCustomers.map((customer) => (
                  <tr key={customer.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-900">{customer.name}</div>
                      <div className="text-sm text-gray-500">
                        Cliente desde {new Date(customer.createdAt).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex flex-col">
                        <div className="flex items-center text-sm text-gray-700">
                          <Mail className="h-4 w-4 mr-1 text-gray-500" />
                          {customer.email}
                        </div>
                        <div className="flex items-center text-sm text-gray-700 mt-1">
                          <Phone className="h-4 w-4 mr-1 text-gray-500" />
                          {customer.phone}
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium text-gray-900">{customer.orders}</td>
                    <td className="py-3 px-4 font-medium text-gray-900">
                      {customer.totalSpent > 0 ? `R$ ${customer.totalSpent.toFixed(2)}` : "-"}
                    </td>
                    <td className="py-3 px-4 text-gray-700">
                      {customer.lastOrder ? new Date(customer.lastOrder).toLocaleDateString() : "-"}
                    </td>
                    <td className="py-3 px-4">
                      {customer.status === "active" ? (
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Ativo</Badge>
                      ) : (
                        <Badge variant="outline" className="text-gray-500 border-gray-300 hover:bg-transparent">
                          Inativo
                        </Badge>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleViewCustomer(customer)}>
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">Ver</span>
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-gray-500">
                    Nenhum cliente encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200">
          <div className="text-sm text-gray-500">
            Mostrando <span className="font-medium">{filteredCustomers.length}</span> de{" "}
            <span className="font-medium">{mockCustomers.length}</span> clientes
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4 mr-1" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" disabled>
              Próximo
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>

      {/* Customer Details Dialog */}
      {selectedCustomer && (
        <Dialog open={isCustomerDialogOpen} onOpenChange={setIsCustomerDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Detalhes do Cliente</DialogTitle>
              <DialogDescription>Informações detalhadas sobre o cliente.</DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="info">
              <TabsList className="grid grid-cols-3 mb-6">
                <TabsTrigger value="info">Informações</TabsTrigger>
                <TabsTrigger value="orders">Pedidos</TabsTrigger>
                <TabsTrigger value="activity">Atividade</TabsTrigger>
              </TabsList>

              <TabsContent value="info">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Informações Pessoais</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <dl className="space-y-4">
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Nome</dt>
                          <dd className="text-base text-gray-900">{selectedCustomer.name}</dd>
                        </div>
                        <div>
                          <dt className="text-sm font-medium text-gray-500">E-mail</dt>
                          <dd className="text-base text-gray-900">{selectedCustomer.email}</dd>
                        </div>
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Telefone</dt>
                          <dd className="text-base text-gray-900">{selectedCustomer.phone}</dd>
                        </div>
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Cliente desde</dt>
                          <dd className="text-base text-gray-900">
                            {new Date(selectedCustomer.createdAt).toLocaleDateString()}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Status</dt>
                          <dd className="text-base">
                            {selectedCustomer.status === "active" ? (
                              <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Ativo</Badge>
                            ) : (
                              <Badge variant="outline" className="text-gray-500 border-gray-300 hover:bg-transparent">
                                Inativo
                              </Badge>
                            )}
                          </dd>
                        </div>
                      </dl>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Resumo de Compras</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <dl className="space-y-4">
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Total de Pedidos</dt>
                          <dd className="text-base text-gray-900">{selectedCustomer.orders}</dd>
                        </div>
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Total Gasto</dt>
                          <dd className="text-base text-gray-900">
                            {selectedCustomer.totalSpent > 0 ? `R$ ${selectedCustomer.totalSpent.toFixed(2)}` : "-"}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Último Pedido</dt>
                          <dd className="text-base text-gray-900">
                            {selectedCustomer.lastOrder
                              ? new Date(selectedCustomer.lastOrder).toLocaleDateString()
                              : "-"}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-sm font-medium text-gray-500">Ticket Médio</dt>
                          <dd className="text-base text-gray-900">
                            {selectedCustomer.orders > 0
                              ? `R$ ${(selectedCustomer.totalSpent / selectedCustomer.orders).toFixed(2)}`
                              : "-"}
                          </dd>
                        </div>
                      </dl>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="orders">
                <Card>
                  <CardHeader>
                    <CardTitle>Histórico de Pedidos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedCustomer.orders > 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-500">Funcionalidade em desenvolvimento.</p>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-500">Este cliente ainda não fez nenhum pedido.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="activity">
                <Card>
                  <CardHeader>
                    <CardTitle>Atividade Recente</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <p className="text-gray-500">Funcionalidade em desenvolvimento.</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

