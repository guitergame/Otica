"use client"

import { useState } from "react"
import {
  Search,
  ChevronRight,
  ChevronLeft,
  ArrowUpDown,
  AlertTriangle,
  AlertCircle,
  Info,
  Eye,
  Calendar,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

// Mock error log data
const mockErrorLogs = [
  {
    id: "1",
    timestamp: "2023-05-10T14:32:15",
    level: "error",
    message: "Failed to process payment for order #ORD-001234",
    source: "payment-service",
    environment: "production",
    details: {
      orderId: "ORD-001234",
      errorCode: "PAYMENT_DECLINED",
      errorMessage: "The payment was declined by the payment processor.",
    },
  },
  {
    id: "2",
    timestamp: "2023-05-10T12:15:43",
    level: "warning",
    message: "Product stock is low (ID: 5)",
    source: "inventory-service",
    environment: "production",
    details: {
      productId: "5",
      currentStock: 3,
      threshold: 5,
    },
  },
  {
    id: "3",
    timestamp: "2023-05-09T18:45:22",
    level: "error",
    message: "Database connection timeout",
    source: "database-service",
    environment: "production",
    details: {
      database: "products",
      errorCode: "CONNECTION_TIMEOUT",
      errorMessage: "Failed to connect to the database after 30 seconds.",
    },
  },
  {
    id: "4",
    timestamp: "2023-05-09T10:12:05",
    level: "info",
    message: "User login successful",
    source: "auth-service",
    environment: "production",
    details: {
      userId: "user123",
      ipAddress: "192.168.1.1",
    },
  },
  {
    id: "5",
    timestamp: "2023-05-08T22:30:18",
    level: "error",
    message: "Failed to send order confirmation email",
    source: "email-service",
    environment: "production",
    details: {
      orderId: "ORD-001230",
      email: "customer@example.com",
      errorCode: "EMAIL_DELIVERY_FAILED",
      errorMessage: "SMTP server connection failed.",
    },
  },
  {
    id: "6",
    timestamp: "2023-05-08T16:20:33",
    level: "warning",
    message: "API rate limit approaching threshold",
    source: "api-gateway",
    environment: "production",
    details: {
      endpoint: "/api/products",
      currentRate: "95 req/min",
      limit: "100 req/min",
    },
  },
]

const levelOptions = [
  { value: "all", label: "Todos os níveis" },
  { value: "error", label: "Erro" },
  { value: "warning", label: "Alerta" },
  { value: "info", label: "Informação" },
]

const sourceOptions = [
  { value: "all", label: "Todas as fontes" },
  { value: "payment-service", label: "Serviço de Pagamento" },
  { value: "inventory-service", label: "Serviço de Inventário" },
  { value: "database-service", label: "Serviço de Banco de Dados" },
  { value: "auth-service", label: "Serviço de Autenticação" },
  { value: "email-service", label: "Serviço de Email" },
  { value: "api-gateway", label: "API Gateway" },
]

export default function ErrorLogsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedLevel, setSelectedLevel] = useState("all")
  const [selectedSource, setSelectedSource] = useState("all")
  const [selectedLog, setSelectedLog] = useState<any>(null)
  const [isLogDialogOpen, setIsLogDialogOpen] = useState(false)

  // Filter logs based on search, level, and source
  const filteredLogs = mockErrorLogs.filter((log) => {
    const matchesSearch =
      log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.source.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesLevel = selectedLevel === "all" || log.level === selectedLevel
    const matchesSource = selectedSource === "all" || log.source === selectedSource

    return matchesSearch && matchesLevel && matchesSource
  })

  const handleViewLog = (log: any) => {
    setSelectedLog(log)
    setIsLogDialogOpen(true)
  }

  const getLevelBadge = (level: string) => {
    switch (level) {
      case "error":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            <AlertCircle className="h-3 w-3 mr-1" />
            Erro
          </Badge>
        )
      case "warning":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Alerta
          </Badge>
        )
      case "info":
        return (
          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            <Info className="h-3 w-3 mr-1" />
            Informação
          </Badge>
        )
      default:
        return <Badge variant="outline">{level}</Badge>
    }
  }

  const formatDateTime = (timestamp: string) => {
    const date = new Date(timestamp)
    return `${date.toLocaleDateString()} ${date.toLocaleTimeString()}`
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Logs de Erro</h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar por mensagem ou fonte..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger>
                <SelectValue placeholder="Nível" />
              </SelectTrigger>
              <SelectContent>
                {levelOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedSource} onValueChange={setSelectedSource}>
              <SelectTrigger>
                <SelectValue placeholder="Fonte" />
              </SelectTrigger>
              <SelectContent>
                {sourceOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("")
                setSelectedLevel("all")
                setSelectedSource("all")
              }}
            >
              Limpar Filtros
            </Button>
          </div>
        </div>
      </div>

      {/* Error Logs Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Data/Hora
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Nível</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Mensagem
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Fonte
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-right font-medium text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs.length > 0 ? (
                filteredLogs.map((log) => (
                  <tr key={log.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4 text-gray-700">{formatDateTime(log.timestamp)}</td>
                    <td className="py-3 px-4">{getLevelBadge(log.level)}</td>
                    <td className="py-3 px-4 font-medium text-gray-900">{log.message}</td>
                    <td className="py-3 px-4 text-gray-700">{log.source}</td>
                    <td className="py-3 px-4 text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleViewLog(log)}>
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">Ver</span>
                      </Button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-500">
                    Nenhum log encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200">
          <div className="text-sm text-gray-500">
            Mostrando <span className="font-medium">{filteredLogs.length}</span> de{" "}
            <span className="font-medium">{mockErrorLogs.length}</span> logs
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4 mr-1" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" disabled>
              Próximo
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>

      {/* Log Details Dialog */}
      {selectedLog && (
        <Dialog open={isLogDialogOpen} onOpenChange={setIsLogDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Detalhes do Log</DialogTitle>
              <DialogDescription>Informações detalhadas sobre o log de erro.</DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-500 mr-2" />
                  <span className="text-sm text-gray-700">{formatDateTime(selectedLog.timestamp)}</span>
                </div>
                {getLevelBadge(selectedLog.level)}
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Mensagem</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-900">{selectedLog.message}</p>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Fonte</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-900">{selectedLog.source}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Ambiente</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-900">{selectedLog.environment}</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Detalhes</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="bg-gray-50 p-4 rounded-md overflow-x-auto text-sm">
                    {JSON.stringify(selectedLog.details, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

