"use client"

import { useState } from "react"
import {
  Search,
  ChevronRight,
  ChevronLeft,
  ArrowUpDown,
  Eye,
  Package,
  Truck,
  CheckCircle,
  XCircle,
  Clock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { ScrollArea } from "@/components/ui/scroll-area"

// Mock order data
const mockOrders = [
  {
    id: "ORD-001234",
    customer: {
      id: "1",
      name: "João Silva",
      email: "joao.silva@example.com",
    },
    date: "2023-05-10",
    status: "delivered",
    total: 599.9,
    items: 2,
    paymentMethod: "credit-card",
    shippingMethod: "standard",
  },
  {
    id: "ORD-001235",
    customer: {
      id: "2",
      name: "Maria Oliveira",
      email: "maria.oliveira@example.com",
    },
    date: "2023-05-09",
    status: "shipped",
    total: 1299.8,
    items: 3,
    paymentMethod: "credit-card",
    shippingMethod: "express",
  },
  {
    id: "ORD-001236",
    customer: {
      id: "3",
      name: "Pedro Santos",
      email: "pedro.santos@example.com",
    },
    date: "2023-05-08",
    status: "processing",
    total: 349.9,
    items: 1,
    paymentMethod: "pix",
    shippingMethod: "standard",
  },
  {
    id: "ORD-001237",
    customer: {
      id: "4",
      name: "Ana Costa",
      email: "ana.costa@example.com",
    },
    date: "2023-05-07",
    status: "delivered",
    total: 799.9,
    items: 2,
    paymentMethod: "boleto",
    shippingMethod: "standard",
  },
  {
    id: "ORD-001238",
    customer: {
      id: "5",
      name: "Carlos Ferreira",
      email: "carlos.ferreira@example.com",
    },
    date: "2023-05-06",
    status: "cancelled",
    total: 499.9,
    items: 1,
    paymentMethod: "credit-card",
    shippingMethod: "express",
  },
  {
    id: "ORD-001239",
    customer: {
      id: "1",
      name: "João Silva",
      email: "joao.silva@example.com",
    },
    date: "2023-05-05",
    status: "pending",
    total: 699.9,
    items: 1,
    paymentMethod: "boleto",
    shippingMethod: "standard",
  },
]

const statusOptions = [
  { value: "all", label: "Todos os status" },
  { value: "pending", label: "Pendente" },
  { value: "processing", label: "Em processamento" },
  { value: "shipped", label: "Enviado" },
  { value: "delivered", label: "Entregue" },
  { value: "cancelled", label: "Cancelado" },
]

// Mock order details
const mockOrderDetails = {
  id: "ORD-001234",
  customer: {
    id: "1",
    name: "João Silva",
    email: "joao.silva@example.com",
    phone: "(11) 98765-4321",
    address: "Av. Paulista, 1000, Apto 123, Bela Vista, São Paulo - SP, 01310-100",
  },
  date: "2023-05-10",
  status: "delivered",
  total: 599.9,
  subtotal: 549.9,
  shipping: 50.0,
  tax: 0,
  discount: 0,
  items: [
    {
      id: "1",
      name: "Óculos de Sol Ray-Ban Aviator",
      brand: "Ray-Ban",
      price: 399.9,
      quantity: 1,
      image: "/placeholder.svg?height=300&width=300",
    },
    {
      id: "2",
      name: "Óculos de Grau Oakley Crosslink",
      brand: "Oakley",
      price: 199.9,
      quantity: 1,
      image: "/placeholder.svg?height=300&width=300",
    },
  ],
  payment: {
    method: "credit-card",
    details: "Cartão de crédito terminando em 1234",
    installments: "2x de R$ 299,95",
  },
  shipping: {
    method: "standard",
    carrier: "Correios",
    trackingNumber: "BR123456789",
    estimatedDelivery: "2023-05-15",
  },
  timeline: [
    { date: "2023-05-10T10:30:00", status: "Pedido realizado" },
    { date: "2023-05-10T14:45:00", status: "Pagamento aprovado" },
    { date: "2023-05-11T09:15:00", status: "Em separação" },
    { date: "2023-05-11T16:30:00", status: "Enviado" },
    { date: "2023-05-15T11:20:00", status: "Entregue" },
  ],
  notes: "Cliente solicitou entrega no período da tarde.",
}

export default function OrdersPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedOrder, setSelectedOrder] = useState<any>(null)
  const [isOrderDialogOpen, setIsOrderDialogOpen] = useState(false)
  const [isUpdateStatusDialogOpen, setIsUpdateStatusDialogOpen] = useState(false)
  const [newStatus, setNewStatus] = useState("")

  // Filter orders based on search and status
  const filteredOrders = mockOrders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.email.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = selectedStatus === "all" || order.status === selectedStatus

    return matchesSearch && matchesStatus
  })

  const handleViewOrder = (order: any) => {
    // In a real app, you would fetch the order details from the API
    setSelectedOrder(mockOrderDetails)
    setIsOrderDialogOpen(true)
  }

  const handleUpdateStatus = (order: any) => {
    setSelectedOrder(order)
    setNewStatus(order.status)
    setIsUpdateStatusDialogOpen(true)
  }

  const confirmUpdateStatus = () => {
    if (selectedOrder && newStatus) {
      // In a real app, this would be an API call
      const updatedOrders = mockOrders.map((order) =>
        order.id === selectedOrder.id ? { ...order, status: newStatus } : order,
      )

      toast({
        title: "Status atualizado",
        description: `O status do pedido ${selectedOrder.id} foi atualizado para ${getStatusLabel(newStatus)}.`,
      })

      setIsUpdateStatusDialogOpen(false)
    }
  }

  const getStatusLabel = (status: string) => {
    const option = statusOptions.find((opt) => opt.value === status)
    return option ? option.label : status
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            <Clock className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        )
      case "processing":
        return (
          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
            <Package className="h-3 w-3 mr-1" />
            Em processamento
          </Badge>
        )
      case "shipped":
        return (
          <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">
            <Truck className="h-3 w-3 mr-1" />
            Enviado
          </Badge>
        )
      case "delivered":
        return (
          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
            <CheckCircle className="h-3 w-3 mr-1" />
            Entregue
          </Badge>
        )
      case "cancelled":
        return (
          <Badge className="bg-red-100 text-red-800 hover:bg-red-100">
            <XCircle className="h-3 w-3 mr-1" />
            Cancelado
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Pedidos</h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar por número do pedido, cliente ou email..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="flex gap-4">
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                {statusOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("")
                setSelectedStatus("all")
              }}
            >
              Limpar Filtros
            </Button>
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Pedido
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Cliente
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Data
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Total
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-right font-medium text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.length > 0 ? (
                filteredOrders.map((order) => (
                  <tr key={order.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-900">{order.id}</td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-900">{order.customer.name}</div>
                      <div className="text-sm text-gray-500">{order.customer.email}</div>
                    </td>
                    <td className="py-3 px-4 text-gray-700">{new Date(order.date).toLocaleDateString()}</td>
                    <td className="py-3 px-4">{getStatusBadge(order.status)}</td>
                    <td className="py-3 px-4 font-medium text-gray-900">R$ {order.total.toFixed(2)}</td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => handleViewOrder(order)}>
                          <Eye className="h-4 w-4" />
                          <span className="sr-only">Ver</span>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleUpdateStatus(order)}>
                          <Package className="h-4 w-4" />
                          <span className="sr-only">Atualizar Status</span>
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-gray-500">
                    Nenhum pedido encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200">
          <div className="text-sm text-gray-500">
            Mostrando <span className="font-medium">{filteredOrders.length}</span> de{" "}
            <span className="font-medium">{mockOrders.length}</span> pedidos
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4 mr-1" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" disabled>
              Próximo
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>

      {/* Order Details Dialog */}
      {selectedOrder && (
        <Dialog open={isOrderDialogOpen} onOpenChange={setIsOrderDialogOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle>Detalhes do Pedido {selectedOrder.id}</DialogTitle>
              <DialogDescription>
                Pedido realizado em {new Date(selectedOrder.date).toLocaleDateString()} •{" "}
                {getStatusBadge(selectedOrder.status)}
              </DialogDescription>
            </DialogHeader>

            <ScrollArea className="flex-1 pr-4">
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid grid-cols-3 mb-6">
                  <TabsTrigger value="details">Detalhes</TabsTrigger>
                  <TabsTrigger value="items">Itens</TabsTrigger>
                  <TabsTrigger value="history">Histórico</TabsTrigger>
                </TabsList>

                <TabsContent value="details">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Informações do Pedido</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <dl className="space-y-4">
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Número do Pedido</dt>
                            <dd className="text-base text-gray-900">{selectedOrder.id}</dd>
                          </div>
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Data</dt>
                            <dd className="text-base text-gray-900">
                              {new Date(selectedOrder.date).toLocaleDateString()}
                            </dd>
                          </div>
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Status</dt>
                            <dd className="text-base">{getStatusBadge(selectedOrder.status)}</dd>
                          </div>
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Método de Pagamento</dt>
                            <dd className="text-base text-gray-900">
                              {selectedOrder.payment.details}
                              {selectedOrder.payment.installments && (
                                <div className="text-sm text-gray-500">{selectedOrder.payment.installments}</div>
                              )}
                            </dd>
                          </div>
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Método de Envio</dt>
                            <dd className="text-base text-gray-900">
                              {selectedOrder.shipping.method === "standard"
                                ? "Padrão (5-7 dias úteis)"
                                : "Expresso (2-3 dias úteis)"}
                              {selectedOrder.shipping.carrier && (
                                <div className="text-sm text-gray-500">
                                  Transportadora: {selectedOrder.shipping.carrier}
                                </div>
                              )}
                            </dd>
                          </div>
                          {selectedOrder.shipping.trackingNumber && (
                            <div>
                              <dt className="text-sm font-medium text-gray-500">Rastreamento</dt>
                              <dd className="text-base text-gray-900">{selectedOrder.shipping.trackingNumber}</dd>
                            </div>
                          )}
                          {selectedOrder.notes && (
                            <div>
                              <dt className="text-sm font-medium text-gray-500">Observações</dt>
                              <dd className="text-base text-gray-900">{selectedOrder.notes}</dd>
                            </div>
                          )}
                        </dl>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Informações do Cliente</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <dl className="space-y-4">
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Nome</dt>
                            <dd className="text-base text-gray-900">{selectedOrder.customer.name}</dd>
                          </div>
                          <div>
                            <dt className="text-sm font-medium text-gray-500">E-mail</dt>
                            <dd className="text-base text-gray-900">{selectedOrder.customer.email}</dd>
                          </div>
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Telefone</dt>
                            <dd className="text-base text-gray-900">{selectedOrder.customer.phone}</dd>
                          </div>
                          <div>
                            <dt className="text-sm font-medium text-gray-500">Endereço de Entrega</dt>
                            <dd className="text-base text-gray-900">{selectedOrder.customer.address}</dd>
                          </div>
                        </dl>
                      </CardContent>
                      <CardFooter>
                        <Button variant="outline" size="sm" className="w-full">
                          Ver Perfil do Cliente
                        </Button>
                      </CardFooter>
                    </Card>
                  </div>

                  <Card className="mt-6">
                    <CardHeader>
                      <CardTitle>Resumo Financeiro</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Subtotal</span>
                          <span className="text-gray-900">R$ {selectedOrder.subtotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Frete</span>
                          <span className="text-gray-900">R$ {selectedOrder.shipping.toFixed(2)}</span>
                        </div>
                        {selectedOrder.tax > 0 && (
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Impostos</span>
                            <span className="text-gray-900">R$ {selectedOrder.tax.toFixed(2)}</span>
                          </div>
                        )}
                        {selectedOrder.discount > 0 && (
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Desconto</span>
                            <span className="text-gray-900">-R$ {selectedOrder.discount.toFixed(2)}</span>
                          </div>
                        )}
                        <div className="border-t border-gray-200 pt-3 mt-3">
                          <div className="flex justify-between font-bold">
                            <span className="text-gray-900">Total</span>
                            <span className="text-gray-900">R$ {selectedOrder.total.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="items">
                  <Card>
                    <CardHeader>
                      <CardTitle>Itens do Pedido</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {selectedOrder.items.map((item: any) => (
                          <div
                            key={item.id}
                            className="flex gap-4 pb-4 border-b border-gray-100 last:border-0 last:pb-0"
                          >
                            <div className="relative w-16 h-16 flex-shrink-0">
                              <img
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                                className="object-cover rounded-md w-full h-full"
                              />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium text-gray-900">{item.name}</h4>
                              <p className="text-sm text-gray-500">{item.brand}</p>
                              <div className="flex justify-between mt-1">
                                <span className="text-sm text-gray-700">Qtd: {item.quantity}</span>
                                <span className="font-medium text-gray-900">R$ {item.price.toFixed(2)}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="history">
                  <Card>
                    <CardHeader>
                      <CardTitle>Histórico do Pedido</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ol className="relative border-l border-gray-200 ml-3">
                        {selectedOrder.timeline.map((event: any, index: number) => (
                          <li key={index} className="mb-6 ml-6 last:mb-0">
                            <span className="absolute flex items-center justify-center w-6 h-6 bg-purple-100 rounded-full -left-3 ring-8 ring-white">
                              <Clock className="w-3 h-3 text-purple-800" />
                            </span>
                            <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900">
                              {event.status}
                              {index === selectedOrder.timeline.length - 1 && (
                                <span className="bg-purple-100 text-purple-800 text-sm font-medium mr-2 px-2.5 py-0.5 rounded ml-3">
                                  Atual
                                </span>
                              )}
                            </h3>
                            <time className="block mb-2 text-sm font-normal leading-none text-gray-500">
                              {new Date(event.date).toLocaleString()}
                            </time>
                          </li>
                        ))}
                      </ol>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </ScrollArea>

            <DialogFooter className="mt-6">
              <Button variant="outline" onClick={() => setIsOrderDialogOpen(false)}>
                Fechar
              </Button>
              <Button onClick={() => handleUpdateStatus(selectedOrder)}>Atualizar Status</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Update Status Dialog */}
      {selectedOrder && (
        <Dialog open={isUpdateStatusDialogOpen} onOpenChange={setIsUpdateStatusDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Atualizar Status do Pedido</DialogTitle>
              <DialogDescription>Atualize o status do pedido {selectedOrder.id}.</DialogDescription>
            </DialogHeader>

            <div className="py-4">
              <Label htmlFor="status">Status</Label>
              <Select value={newStatus} onValueChange={setNewStatus}>
                <SelectTrigger className="w-full mt-1">
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pendente</SelectItem>
                  <SelectItem value="processing">Em processamento</SelectItem>
                  <SelectItem value="shipped">Enviado</SelectItem>
                  <SelectItem value="delivered">Entregue</SelectItem>
                  <SelectItem value="cancelled">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsUpdateStatusDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={confirmUpdateStatus} className="bg-purple-600 hover:bg-purple-700">
                Atualizar Status
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

