"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Plus, Search, Edit, Trash2, ChevronLeft, ChevronRight, Filter, ArrowUpDown, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"

// Mock product data
const mockProducts = [
  {
    id: "1",
    name: "Óculos de Sol Ray-Ban Aviator",
    brand: "Ray-Ban",
    price: 599.9,
    originalPrice: 799.9,
    discount: 25,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    stock: 15,
    isNew: false,
    isActive: true,
  },
  {
    id: "2",
    name: "Óculos de Grau Oakley Crosslink",
    brand: "Oakley",
    price: 699.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    stock: 8,
    isNew: true,
    isActive: true,
  },
  {
    id: "3",
    name: "Lentes de Contato Coloridas Solotica",
    brand: "Solotica",
    price: 149.9,
    originalPrice: 199.9,
    discount: 25,
    image: "/placeholder.svg?height=300&width=300",
    category: "lentes-de-contato",
    stock: 30,
    isNew: false,
    isActive: true,
  },
  {
    id: "4",
    name: "Óculos de Sol Prada Linea Rossa",
    brand: "Prada",
    price: 1299.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    stock: 5,
    isNew: true,
    isActive: true,
  },
  {
    id: "5",
    name: "Óculos de Grau Vogue VO5286",
    brand: "Vogue",
    price: 499.9,
    originalPrice: 599.9,
    discount: 16,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    stock: 12,
    isNew: false,
    isActive: true,
  },
  {
    id: "6",
    name: "Lentes de Contato Acuvue Oasys",
    brand: "Acuvue",
    price: 179.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "lentes-de-contato",
    stock: 25,
    isNew: false,
    isActive: false,
  },
  {
    id: "7",
    name: "Óculos de Sol Versace VE4361",
    brand: "Versace",
    price: 1099.9,
    originalPrice: 1399.9,
    discount: 21,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    stock: 3,
    isNew: false,
    isActive: true,
  },
  {
    id: "8",
    name: "Óculos de Grau Tommy Hilfiger TH1689",
    brand: "Tommy Hilfiger",
    price: 599.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    stock: 10,
    isNew: true,
    isActive: true,
  },
]

const categories = [
  { value: "all", label: "Todas as categorias" },
  { value: "oculos-de-sol", label: "Óculos de Sol" },
  { value: "oculos-de-grau", label: "Óculos de Grau" },
  { value: "lentes-de-contato", label: "Lentes de Contato" },
  { value: "acessorios", label: "Acessórios" },
]

const brands = [
  { value: "all", label: "Todas as marcas" },
  { value: "ray-ban", label: "Ray-Ban" },
  { value: "oakley", label: "Oakley" },
  { value: "prada", label: "Prada" },
  { value: "versace", label: "Versace" },
  { value: "vogue", label: "Vogue" },
  { value: "tommy-hilfiger", label: "Tommy Hilfiger" },
  { value: "solotica", label: "Solotica" },
  { value: "acuvue", label: "Acuvue" },
]

export default function ProductsPage() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedBrand, setSelectedBrand] = useState("all")
  const [showActive, setShowActive] = useState(true)
  const [showInactive, setShowInactive] = useState(true)
  const [products, setProducts] = useState(mockProducts)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [productToDelete, setProductToDelete] = useState<string | null>(null)
  const [isAddProductDialogOpen, setIsAddProductDialogOpen] = useState(false)
  const [newProduct, setNewProduct] = useState({
    name: "",
    brand: "",
    price: "",
    originalPrice: "",
    category: "",
    stock: "",
    description: "",
    isNew: false,
    isActive: true,
  })

  // Filter products based on search, category, brand, and status
  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    const matchesBrand = selectedBrand === "all" || product.brand.toLowerCase() === selectedBrand
    const matchesStatus = (showActive && product.isActive) || (showInactive && !product.isActive)

    return matchesSearch && matchesCategory && matchesBrand && matchesStatus
  })

  const handleDeleteProduct = (id: string) => {
    setProductToDelete(id)
    setIsDeleteDialogOpen(true)
  }

  const confirmDeleteProduct = () => {
    if (productToDelete) {
      setProducts(products.filter((product) => product.id !== productToDelete))
      toast({
        title: "Produto excluído",
        description: "O produto foi excluído com sucesso.",
      })
      setIsDeleteDialogOpen(false)
      setProductToDelete(null)
    }
  }

  const handleAddProduct = () => {
    // Validate form
    if (!newProduct.name || !newProduct.brand || !newProduct.price || !newProduct.category || !newProduct.stock) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive",
      })
      return
    }

    // Create new product
    const product = {
      id: `${products.length + 1}`,
      name: newProduct.name,
      brand: newProduct.brand,
      price: Number.parseFloat(newProduct.price),
      originalPrice: newProduct.originalPrice ? Number.parseFloat(newProduct.originalPrice) : undefined,
      discount: newProduct.originalPrice
        ? Math.round(
            ((Number.parseFloat(newProduct.originalPrice) - Number.parseFloat(newProduct.price)) /
              Number.parseFloat(newProduct.originalPrice)) *
              100,
          )
        : undefined,
      image: "/placeholder.svg?height=300&width=300",
      category: newProduct.category,
      stock: Number.parseInt(newProduct.stock),
      isNew: newProduct.isNew,
      isActive: newProduct.isActive,
    }

    setProducts([...products, product])
    toast({
      title: "Produto adicionado",
      description: "O produto foi adicionado com sucesso.",
    })

    // Reset form
    setNewProduct({
      name: "",
      brand: "",
      price: "",
      originalPrice: "",
      category: "",
      stock: "",
      description: "",
      isNew: false,
      isActive: true,
    })

    setIsAddProductDialogOpen(false)
  }

  const handleNewProductChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setNewProduct((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setNewProduct((prev) => ({ ...prev, [name]: checked }))
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Produtos</h1>
        <Button
          onClick={() => setIsAddProductDialogOpen(true)}
          className="mt-4 md:mt-0 bg-purple-600 hover:bg-purple-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Adicionar Produto
        </Button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Buscar produtos..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedBrand} onValueChange={setSelectedBrand}>
              <SelectTrigger>
                <SelectValue placeholder="Marca" />
              </SelectTrigger>
              <SelectContent>
                {brands.map((brand) => (
                  <SelectItem key={brand.value} value={brand.value}>
                    {brand.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="w-full justify-between">
                  <div className="flex items-center">
                    <Filter className="mr-2 h-4 w-4" />
                    Status
                  </div>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="p-2">
                  <div className="flex items-center space-x-2 mb-2">
                    <Checkbox
                      id="active"
                      checked={showActive}
                      onCheckedChange={(checked) => setShowActive(checked as boolean)}
                    />
                    <label
                      htmlFor="active"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Ativos
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="inactive"
                      checked={showInactive}
                      onCheckedChange={(checked) => setShowInactive(checked as boolean)}
                    />
                    <label
                      htmlFor="inactive"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Inativos
                    </label>
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery("")
                setSelectedCategory("all")
                setSelectedBrand("all")
                setShowActive(true)
                setShowInactive(true)
              }}
            >
              Limpar Filtros
            </Button>
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="py-3 px-4 text-left font-medium text-gray-700">Produto</th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Categoria
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Preço
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">
                  <div className="flex items-center">
                    Estoque
                    <ArrowUpDown className="ml-1 h-4 w-4" />
                  </div>
                </th>
                <th className="py-3 px-4 text-left font-medium text-gray-700">Status</th>
                <th className="py-3 px-4 text-right font-medium text-gray-700">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <tr key={product.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <div className="relative w-10 h-10 mr-3 rounded overflow-hidden">
                          <Image
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{product.name}</div>
                          <div className="text-sm text-gray-500">{product.brand}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-700">
                      {product.category === "oculos-de-sol" && "Óculos de Sol"}
                      {product.category === "oculos-de-grau" && "Óculos de Grau"}
                      {product.category === "lentes-de-contato" && "Lentes de Contato"}
                      {product.category === "acessorios" && "Acessórios"}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-gray-900">R$ {product.price.toFixed(2)}</div>
                      {product.originalPrice && (
                        <div className="text-xs text-gray-500 line-through">R$ {product.originalPrice.toFixed(2)}</div>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <div
                        className={`font-medium ${
                          product.stock <= 5
                            ? "text-red-600"
                            : product.stock <= 10
                              ? "text-amber-600"
                              : "text-green-600"
                        }`}
                      >
                        {product.stock} unidades
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {product.isActive ? (
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Ativo</Badge>
                      ) : (
                        <Badge variant="outline" className="text-gray-500 border-gray-300 hover:bg-transparent">
                          Inativo
                        </Badge>
                      )}
                      {product.isNew && (
                        <Badge className="ml-2 bg-blue-100 text-blue-800 hover:bg-blue-100">Novo</Badge>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/admin/dashboard/products/${product.id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">Ver</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/admin/dashboard/products/${product.id}/edit`}>
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Editar</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteProduct(product.id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                          <span className="sr-only">Excluir</span>
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-gray-500">
                    Nenhum produto encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200">
          <div className="text-sm text-gray-500">
            Mostrando <span className="font-medium">{filteredProducts.length}</span> de{" "}
            <span className="font-medium">{products.length}</span> produtos
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4 mr-1" />
              Anterior
            </Button>
            <Button variant="outline" size="sm" disabled>
              Próximo
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Excluir Produto</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmDeleteProduct}>
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Product Dialog */}
      <Dialog open={isAddProductDialogOpen} onOpenChange={setIsAddProductDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Adicionar Produto</DialogTitle>
            <DialogDescription>Preencha os campos abaixo para adicionar um novo produto.</DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Produto *</Label>
              <Input id="name" name="name" value={newProduct.name} onChange={handleNewProductChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="brand">Marca *</Label>
              <Input id="brand" name="brand" value={newProduct.brand} onChange={handleNewProductChange} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Categoria *</Label>
              <select
                id="category"
                name="category"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                value={newProduct.category}
                onChange={handleNewProductChange}
                required
              >
                <option value="">Selecione uma categoria</option>
                <option value="oculos-de-sol">Óculos de Sol</option>
                <option value="oculos-de-grau">Óculos de Grau</option>
                <option value="lentes-de-contato">Lentes de Contato</option>
                <option value="acessorios">Acessórios</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="stock">Estoque *</Label>
              <Input
                id="stock"
                name="stock"
                type="number"
                min="0"
                value={newProduct.stock}
                onChange={handleNewProductChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">Preço (R$) *</Label>
              <Input
                id="price"
                name="price"
                type="number"
                min="0"
                step="0.01"
                value={newProduct.price}
                onChange={handleNewProductChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="originalPrice">Preço Original (R$)</Label>
              <Input
                id="originalPrice"
                name="originalPrice"
                type="number"
                min="0"
                step="0.01"
                value={newProduct.originalPrice}
                onChange={handleNewProductChange}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                name="description"
                value={newProduct.description}
                onChange={handleNewProductChange}
                rows={3}
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isNew"
                  checked={newProduct.isNew}
                  onCheckedChange={(checked) => handleCheckboxChange("isNew", checked as boolean)}
                />
                <Label htmlFor="isNew">Marcar como novo</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="isActive"
                  checked={newProduct.isActive}
                  onCheckedChange={(checked) => handleCheckboxChange("isActive", checked as boolean)}
                />
                <Label htmlFor="isActive">Produto ativo</Label>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddProductDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddProduct} className="bg-purple-600 hover:bg-purple-700">
              Adicionar Produto
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

