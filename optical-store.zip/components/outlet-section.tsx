"use client"

import { useState } from "react"
import ProductCard, { type Product } from "@/components/product-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Mock data for outlet products
const outletProducts: Record<string, Product[]> = {
  "oculos-de-sol": [
    {
      id: "outlet1",
      name: "Óculos de Sol Ray-Ban Justin",
      brand: "Ray-Ban",
      price: 399.9,
      originalPrice: 699.9,
      discount: 43,
      image: "/placeholder.svg?height=300&width=300",
      category: "oculos-de-sol",
      colors: ["#000000", "#714B23"],
    },
    {
      id: "outlet2",
      name: "Óculos de Sol Oakley Holbrook",
      brand: "Oakley",
      price: 449.9,
      originalPrice: 799.9,
      discount: 44,
      image: "/placeholder.svg?height=300&width=300",
      category: "oculos-de-sol",
      colors: ["#000000", "#1A2B3C"],
    },
  ],
  "oculos-de-grau": [
    {
      id: "outlet3",
      name: "Óculos de Grau Tommy Hilfiger TH1234",
      brand: "Tommy Hilfiger",
      price: 349.9,
      originalPrice: 599.9,
      discount: 42,
      image: "/placeholder.svg?height=300&width=300",
      category: "oculos-de-grau",
      colors: ["#000000", "#0F4D92"],
    },
    {
      id: "outlet4",
      name: "Óculos de Grau Vogue VO5123",
      brand: "Vogue",
      price: 299.9,
      originalPrice: 499.9,
      discount: 40,
      image: "/placeholder.svg?height=300&width=300",
      category: "oculos-de-grau",
      colors: ["#000000", "#8B4513"],
    },
  ],
  "lentes-de-contato": [
    {
      id: "outlet5",
      name: "Lentes de Contato Coloridas FreshLook",
      brand: "FreshLook",
      price: 99.9,
      originalPrice: 149.9,
      discount: 33,
      image: "/placeholder.svg?height=300&width=300",
      category: "lentes-de-contato",
      colors: ["#A5764E", "#0F4D92"],
    },
  ],
}

export default function OutletSection() {
  const [activeTab, setActiveTab] = useState("oculos-de-sol")

  return (
    <Tabs defaultValue="oculos-de-sol" onValueChange={setActiveTab} className="w-full">
      <TabsList className="mb-6 bg-white border border-gray-200">
        <TabsTrigger value="oculos-de-sol">Óculos de Sol</TabsTrigger>
        <TabsTrigger value="oculos-de-grau">Óculos de Grau</TabsTrigger>
        <TabsTrigger value="lentes-de-contato">Lentes de Contato</TabsTrigger>
      </TabsList>

      {Object.keys(outletProducts).map((category) => (
        <TabsContent key={category} value={category} className="mt-0">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {outletProducts[category].map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </TabsContent>
      ))}
    </Tabs>
  )
}

