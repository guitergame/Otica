import Link from "next/link"
import Image from "next/image"
import { Heart, ShoppingCart, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

export type Product = {
  id: string
  name: string
  brand: string
  price: number
  originalPrice?: number
  discount?: number
  image: string
  category: string
  colors?: string[]
  isNew?: boolean
}

interface ProductCardProps {
  product: Product
  className?: string
}

export default function ProductCard({ product, className }: ProductCardProps) {
  return (
    <div
      className={cn(
        "group relative bg-white rounded-lg overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-md",
        className,
      )}
    >
      {/* Discount Badge */}
      {product.discount && (
        <Badge className="absolute top-2 left-2 z-10 bg-red-500 hover:bg-red-600">-{product.discount}%</Badge>
      )}

      {/* New Badge */}
      {product.isNew && <Badge className="absolute top-2 right-2 z-10 bg-purple-500 hover:bg-purple-600">Novo</Badge>}

      {/* Product Image */}
      <Link href={`/produto/${product.id}`} className="block relative aspect-square overflow-hidden">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />

        {/* Quick Actions Overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-0 flex items-center justify-center gap-2 opacity-0 transition-all duration-300 group-hover:bg-opacity-10 group-hover:opacity-100">
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full h-10 w-10 bg-white text-gray-800 hover:bg-gray-100 hover:text-purple-600"
          >
            <Heart className="h-5 w-5" />
            <span className="sr-only">Adicionar aos favoritos</span>
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full h-10 w-10 bg-white text-gray-800 hover:bg-gray-100 hover:text-purple-600"
          >
            <Eye className="h-5 w-5" />
            <span className="sr-only">Visualização rápida</span>
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full h-10 w-10 bg-white text-gray-800 hover:bg-gray-100 hover:text-purple-600"
          >
            <ShoppingCart className="h-5 w-5" />
            <span className="sr-only">Adicionar ao carrinho</span>
          </Button>
        </div>
      </Link>

      {/* Product Info */}
      <div className="p-4">
        <div className="mb-1">
          <span className="text-sm text-gray-500">{product.brand}</span>
        </div>
        <Link href={`/produto/${product.id}`} className="block">
          <h3 className="font-medium text-gray-900 mb-2 line-clamp-2 hover:text-purple-600 transition-colors">
            {product.name}
          </h3>
        </Link>

        {/* Price */}
        <div className="flex items-center">
          {product.originalPrice ? (
            <>
              <span className="text-lg font-bold text-gray-900">R$ {product.price.toFixed(2)}</span>
              <span className="ml-2 text-sm text-gray-500 line-through">R$ {product.originalPrice.toFixed(2)}</span>
            </>
          ) : (
            <span className="text-lg font-bold text-gray-900">R$ {product.price.toFixed(2)}</span>
          )}
        </div>

        {/* Color Options */}
        {product.colors && product.colors.length > 0 && (
          <div className="mt-3 flex items-center gap-1">
            {product.colors.map((color, index) => (
              <div
                key={index}
                className="w-4 h-4 rounded-full border border-gray-300"
                style={{ backgroundColor: color }}
                title={`Cor ${index + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

