import Link from "next/link"
import Image from "next/image"

const categories = [
  {
    id: 1,
    name: "Óculos de Grau",
    image: "/placeholder.svg?height=300&width=300",
    href: "/categoria/oculos-de-grau",
  },
  {
    id: 2,
    name: "Óculos de Sol",
    image: "/placeholder.svg?height=300&width=300",
    href: "/categoria/oculos-de-sol",
  },
  {
    id: 3,
    name: "Lentes de Contato",
    image: "/placeholder.svg?height=300&width=300",
    href: "/categoria/lentes-de-contato",
  },
  {
    id: 4,
    name: "Acessórios",
    image: "/placeholder.svg?height=300&width=300",
    href: "/categoria/acessorios",
  },
]

export default function CategorySection() {
  return (
    <section className="my-12">
      <h2 className="text-3xl font-bold text-gray-900 mb-6">Categorias</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {categories.map((category) => (
          <Link key={category.id} href={category.href} className="group relative overflow-hidden rounded-lg">
            <div className="aspect-square relative">
              <Image
                src={category.image || "/placeholder.svg"}
                alt={category.name}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-xl font-semibold text-white">{category.name}</h3>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}

