"use client"

import { useState } from "react"
import { MessageCircle, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function WhatsAppChat() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleChat = () => {
    setIsOpen(!isOpen)
  }

  const openWhatsApp = () => {
    window.open(
      "https://wa.me/5511999999999?text=Olá,%20gostaria%20de%20saber%20mais%20sobre%20os%20produtos.",
      "_blank",
    )
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen && (
        <div className="bg-white rounded-lg shadow-lg p-4 mb-4 w-72 border border-gray-200 animate-in slide-in-from-bottom-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Atendimento</h3>
            <Button variant="ghost" size="icon" onClick={toggleChat} className="h-8 w-8">
              <X className="h-4 w-4" />
              <span className="sr-only">Fechar chat</span>
            </Button>
          </div>
          <p className="text-gray-700 mb-4">
            Olá! Como podemos ajudar você hoje? Clique abaixo para falar com um de nossos atendentes.
          </p>
          <Button onClick={openWhatsApp} className="w-full bg-green-600 hover:bg-green-700">
            <MessageCircle className="h-5 w-5 mr-2" />
            Iniciar conversa
          </Button>
        </div>
      )}

      <Button
        onClick={toggleChat}
        className={`rounded-full h-14 w-14 shadow-lg ${isOpen ? "bg-red-500 hover:bg-red-600" : "bg-green-600 hover:bg-green-700"}`}
        aria-label={isOpen ? "Fechar chat" : "Abrir chat"}
      >
        {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </Button>
    </div>
  )
}

