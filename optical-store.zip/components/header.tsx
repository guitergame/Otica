"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
// Import additional icons for gender categories
import {
  Search,
  ShoppingCart,
  Heart,
  User,
  Menu,
  UserIcon as Male,
  UserIcon as Female,
  Users,
  Baby,
  Tag,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useCart } from "@/components/cart-provider"
import { useWishlist } from "@/components/wishlist-provider"
import { useAuth } from "@/components/auth-provider"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"

const mainCategories = [
  { name: "Óculos de Grau", href: "/categoria/oculos-de-grau" },
  { name: "Óculos de Sol", href: "/categoria/oculos-de-sol" },
  { name: "Lentes de Contato", href: "/categoria/lentes-de-contato" },
  { name: "Outlet", href: "/outlet" },
]

const subCategories = [
  { name: "Masculino", href: "/genero/masculino" },
  { name: "Feminino", href: "/genero/feminino" },
  { name: "Unissex", href: "/genero/unissex" },
  { name: "Infantil", href: "/genero/infantil" },
]

export default function Header() {
  const [searchQuery, setSearchQuery] = useState("")
  const pathname = usePathname()
  const { cartItems } = useCart()
  const { wishlistItems } = useWishlist()
  const { user, isAuthenticated } = useAuth()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement search functionality
    window.location.href = `/busca?q=${encodeURIComponent(searchQuery)}`
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white">
      <div className="container mx-auto px-4">
        {/* Top bar with logo and search */}
        <div className="flex items-center justify-between py-4">
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold text-purple-700">Ótica Premium</span>
          </Link>

          {/* Search bar - hidden on mobile */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Input
                type="search"
                placeholder="Buscar produtos, marcas..."
                className="w-full pr-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2">
                <Search className="h-4 w-4 text-gray-500" />
              </button>
            </div>
          </form>

          {/* User actions */}
          <div className="flex items-center space-x-4">
            <Link href="/wishlist" className="relative">
              <Heart className="h-6 w-6 text-gray-700" />
              {wishlistItems.length > 0 && (
                <Badge
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
                >
                  {wishlistItems.length}
                </Badge>
              )}
            </Link>

            <Link href="/cart" className="relative">
              <ShoppingCart className="h-6 w-6 text-gray-700" />
              {cartItems.length > 0 && (
                <Badge
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
                >
                  {cartItems.length}
                </Badge>
              )}
            </Link>

            {isAuthenticated ? (
              <Link href="/minha-conta">
                <Button variant="ghost" className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  <span className="hidden md:inline">Minha Conta</span>
                </Button>
              </Link>
            ) : (
              <Link href="/login">
                <Button variant="ghost" className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  <span className="hidden md:inline">Entrar</span>
                </Button>
              </Link>
            )}

            {/* Mobile menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 py-4">
                  <form onSubmit={handleSearch} className="flex w-full">
                    <div className="relative w-full">
                      <Input
                        type="search"
                        placeholder="Buscar produtos, marcas..."
                        className="w-full pr-10"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2">
                        <Search className="h-4 w-4 text-gray-500" />
                      </button>
                    </div>
                  </form>

                  <nav className="flex flex-col gap-2">
                    <h3 className="font-semibold text-lg">Categorias</h3>
                    {mainCategories.map((category) => (
                      <Link
                        key={category.href}
                        href={category.href}
                        className={cn(
                          "text-gray-700 hover:text-purple-700 py-2",
                          pathname === category.href && "text-purple-700 font-medium",
                        )}
                      >
                        {category.name}
                      </Link>
                    ))}

                    <h3 className="font-semibold text-lg mt-4">Gênero</h3>
                    {subCategories.map((category) => (
                      <Link
                        key={category.href}
                        href={category.href}
                        className={cn(
                          "text-gray-700 hover:text-purple-700 py-2",
                          pathname === category.href && "text-purple-700 font-medium",
                        )}
                      >
                        {category.name}
                      </Link>
                    ))}
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Main navigation - hidden on mobile */}
        <nav className="hidden md:flex items-center py-3">
          <div className="flex items-center space-x-6">
            {/* Gender and Outlet Dropdown Menus */}
            <div className="group relative">
              <Link
                href="/genero/masculino"
                className={cn(
                  "text-gray-600 hover:text-purple-700 text-sm flex items-center",
                  pathname === "/genero/masculino" && "text-purple-700",
                )}
              >
                <Male className="h-4 w-4 mr-1" />
                Masculino
              </Link>
              <div className="absolute left-0 top-full mt-1 w-48 bg-white shadow-lg rounded-md overflow-hidden z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div className="py-2">
                  <Link
                    href="/genero/masculino/oculos-de-grau"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Grau
                  </Link>
                  <Link
                    href="/genero/masculino/oculos-de-sol"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Sol
                  </Link>
                  <Link
                    href="/genero/masculino/lentes-de-contato"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Lentes de Contato
                  </Link>
                </div>
              </div>
            </div>

            <div className="group relative">
              <Link
                href="/genero/feminino"
                className={cn(
                  "text-gray-600 hover:text-purple-700 text-sm flex items-center",
                  pathname === "/genero/feminino" && "text-purple-700",
                )}
              >
                <Female className="h-4 w-4 mr-1" />
                Feminino
              </Link>
              <div className="absolute left-0 top-full mt-1 w-48 bg-white shadow-lg rounded-md overflow-hidden z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div className="py-2">
                  <Link
                    href="/genero/feminino/oculos-de-grau"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Grau
                  </Link>
                  <Link
                    href="/genero/feminino/oculos-de-sol"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Sol
                  </Link>
                  <Link
                    href="/genero/feminino/lentes-de-contato"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Lentes de Contato
                  </Link>
                </div>
              </div>
            </div>

            <div className="group relative">
              <Link
                href="/genero/unissex"
                className={cn(
                  "text-gray-600 hover:text-purple-700 text-sm flex items-center",
                  pathname === "/genero/unissex" && "text-purple-700",
                )}
              >
                <Users className="h-4 w-4 mr-1" />
                Unissex
              </Link>
              <div className="absolute left-0 top-full mt-1 w-48 bg-white shadow-lg rounded-md overflow-hidden z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div className="py-2">
                  <Link
                    href="/genero/unissex/oculos-de-grau"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Grau
                  </Link>
                  <Link
                    href="/genero/unissex/oculos-de-sol"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Sol
                  </Link>
                  <Link
                    href="/genero/unissex/lentes-de-contato"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Lentes de Contato
                  </Link>
                </div>
              </div>
            </div>

            <div className="group relative">
              <Link
                href="/genero/infantil"
                className={cn(
                  "text-gray-600 hover:text-purple-700 text-sm flex items-center",
                  pathname === "/genero/infantil" && "text-purple-700",
                )}
              >
                <Baby className="h-4 w-4 mr-1" />
                Infantil
              </Link>
              <div className="absolute left-0 top-full mt-1 w-48 bg-white shadow-lg rounded-md overflow-hidden z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                <div className="py-2">
                  <Link
                    href="/genero/infantil/oculos-de-grau"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Grau
                  </Link>
                  <Link
                    href="/genero/infantil/oculos-de-sol"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Óculos de Sol
                  </Link>
                  <Link
                    href="/genero/infantil/lentes-de-contato"
                    className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Lentes de Contato
                  </Link>
                </div>
              </div>
            </div>

            <Link
              href="/outlet"
              className={cn(
                "text-gray-600 hover:text-purple-700 text-sm flex items-center",
                pathname === "/outlet" && "text-purple-700",
              )}
            >
              <Tag className="h-4 w-4 mr-1" />
              Outlet
            </Link>
          </div>
        </nav>
      </div>
    </header>
  )
}

