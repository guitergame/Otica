"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const newReleases = [
  {
    id: "new1",
    name: "Óculos de Sol Gucci GG0896S",
    brand: "Gucci",
    price: 1899.9,
    image: "/placeholder.svg?height=400&width=400",
    category: "oculos-de-sol",
  },
  {
    id: "new2",
    name: "Óculos de Grau Dior DIORETOILE1",
    brand: "Dior",
    price: 2199.9,
    image: "/placeholder.svg?height=400&width=400",
    category: "oculos-de-grau",
  },
  {
    id: "new3",
    name: "Óculos de Sol Prada PR 17WS",
    brand: "Prada",
    price: 1599.9,
    image: "/placeholder.svg?height=400&width=400",
    category: "oculos-de-sol",
  },
  {
    id: "new4",
    name: "Óculos de Grau Burberry BE2345",
    brand: "Burberry",
    price: 1299.9,
    image: "/placeholder.svg?height=400&width=400",
    category: "oculos-de-grau",
  },
  {
    id: "new5",
    name: "Lentes de Contato Air Optix Colors",
    brand: "Air Optix",
    price: 189.9,
    image: "/placeholder.svg?height=400&width=400",
    category: "lentes-de-contato",
  },
]

export default function NewReleases() {
  const [startIndex, setStartIndex] = useState(0)
  const itemsToShow = 4

  const nextSlide = () => {
    setStartIndex((prev) => (prev + itemsToShow >= newReleases.length ? 0 : prev + 1))
  }

  const prevSlide = () => {
    setStartIndex((prev) => (prev === 0 ? Math.max(0, newReleases.length - itemsToShow) : prev - 1))
  }

  const visibleReleases = newReleases.slice(startIndex, startIndex + itemsToShow)

  // If we don't have enough items from the start index, wrap around to the beginning
  if (visibleReleases.length < itemsToShow) {
    visibleReleases.push(...newReleases.slice(0, itemsToShow - visibleReleases.length))
  }

  return (
    <div className="relative">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {visibleReleases.map((product) => (
          <div
            key={product.id}
            className="group relative bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200"
          >
            <Badge className="absolute top-2 right-2 z-10 bg-green-600">Novo</Badge>

            <Link href={`/produto/${product.id}`} className="block relative aspect-square">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </Link>

            <div className="p-4">
              <div className="mb-1 text-sm text-gray-500">{product.brand}</div>
              <Link href={`/produto/${product.id}`}>
                <h3 className="font-medium text-gray-900 mb-2 line-clamp-2 hover:text-purple-700 transition-colors">
                  {product.name}
                </h3>
              </Link>

              <div className="mt-2">
                <span className="font-semibold text-lg text-gray-900">R$ {product.price.toFixed(2)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {newReleases.length > itemsToShow && (
        <>
          <button
            onClick={prevSlide}
            className="absolute -left-4 top-1/2 -translate-y-1/2 bg-white shadow-md hover:bg-gray-100 text-gray-800 p-2 rounded-full hidden md:block"
            aria-label="Produtos anteriores"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute -right-4 top-1/2 -translate-y-1/2 bg-white shadow-md hover:bg-gray-100 text-gray-800 p-2 rounded-full hidden md:block"
            aria-label="Próximos produtos"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </>
      )}
    </div>
  )
}

