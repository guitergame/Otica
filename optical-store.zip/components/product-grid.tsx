"use client"

import { useState, useEffect } from "react"
import ProductCard, { type Product } from "@/components/product-card"

// Mock data - in a real app, this would come from an API
const mockProducts: Product[] = [
  {
    id: "1",
    name: "Óculos de Sol Ray-Ban Aviator",
    brand: "Ray-Ban",
    price: 599.9,
    originalPrice: 799.9,
    discount: 25,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    colors: ["#000000", "#714B23", "#0F4D92"],
  },
  {
    id: "2",
    name: "Óculos de Grau Oakley Crosslink",
    brand: "Oakley",
    price: 699.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    isNew: true,
    colors: ["#000000", "#545454", "#1A2B3C"],
  },
  {
    id: "3",
    name: "Lentes de Contato Coloridas Solotica",
    brand: "Solotica",
    price: 149.9,
    originalPrice: 199.9,
    discount: 25,
    image: "/placeholder.svg?height=300&width=300",
    category: "lentes-de-contato",
    colors: ["#A5764E", "#0F4D92", "#2D5335"],
  },
  {
    id: "4",
    name: "Óculos de Sol Prada Linea Rossa",
    brand: "Prada",
    price: 1299.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    isNew: true,
    colors: ["#000000", "#1A1A1A"],
  },
  {
    id: "5",
    name: "Óculos de Grau Vogue VO5286",
    brand: "Vogue",
    price: 499.9,
    originalPrice: 599.9,
    discount: 16,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    colors: ["#000000", "#8B4513", "#4B0082"],
  },
  {
    id: "6",
    name: "Lentes de Contato Acuvue Oasys",
    brand: "Acuvue",
    price: 179.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "lentes-de-contato",
  },
  {
    id: "7",
    name: "Óculos de Sol Versace VE4361",
    brand: "Versace",
    price: 1099.9,
    originalPrice: 1399.9,
    discount: 21,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-sol",
    colors: ["#000000", "#C0C0C0", "#FFD700"],
  },
  {
    id: "8",
    name: "Óculos de Grau Tommy Hilfiger TH1689",
    brand: "Tommy Hilfiger",
    price: 599.9,
    image: "/placeholder.svg?height=300&width=300",
    category: "oculos-de-grau",
    isNew: true,
    colors: ["#000000", "#0F4D92", "#8B0000"],
  },
]

interface ProductGridProps {
  category?: string
  featured?: boolean
  limit?: number
}

export default function ProductGrid({ category, featured, limit }: ProductGridProps) {
  const [products, setProducts] = useState<Product[]>([])

  useEffect(() => {
    // Filter products based on props
    let filteredProducts = [...mockProducts]

    if (category && category !== "featured") {
      filteredProducts = filteredProducts.filter((p) => p.category === category)
    }

    if (featured || category === "featured") {
      // For featured, we'd typically have a "featured" flag in the product data
      // Here we're just showing some products as featured for demo purposes
      filteredProducts = mockProducts.filter((_, index) => index % 2 === 0)
    }

    if (limit) {
      filteredProducts = filteredProducts.slice(0, limit)
    }

    setProducts(filteredProducts)
  }, [category, featured, limit])

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Nenhum produto encontrado.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}

