import Image from "next/image"
import Link from "next/link"

const brands = [
  { id: 1, name: "Ray-Ban", logo: "/placeholder.svg?height=100&width=200", href: "/marca/ray-ban" },
  { id: 2, name: "Oakley", logo: "/placeholder.svg?height=100&width=200", href: "/marca/oakley" },
  { id: 3, name: "Prada", logo: "/placeholder.svg?height=100&width=200", href: "/marca/prada" },
  { id: 4, name: "Gucci", logo: "/placeholder.svg?height=100&width=200", href: "/marca/gucci" },
  { id: 5, name: "Dior", logo: "/placeholder.svg?height=100&width=200", href: "/marca/dior" },
  { id: 6, name: "Versace", logo: "/placeholder.svg?height=100&width=200", href: "/marca/versace" },
]

export default function FeaturedBrands() {
  return (
    <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
      {brands.map((brand) => (
        <Link
          key={brand.id}
          href={brand.href}
          className="flex items-center justify-center p-4 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
        >
          <div className="relative h-12 w-full">
            <Image src={brand.logo || "/placeholder.svg"} alt={brand.name} fill className="object-contain" />
          </div>
        </Link>
      ))}
    </div>
  )
}

